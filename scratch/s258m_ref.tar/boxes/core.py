"""THEORY §66: GPT-2 state tracking (4 boxes, swap operations; S4) with arms NC, TC, TC2, CL, WC(k), WC0(k).

Text format (GPT-2 BPE; every op and every arrangement has a fixed token length, so batches of equal N and question
type need no padding):
  prompt   "start: B D A C. ops: swap 1 3, swap 2 4. q: all. a:"      answer " B D A C"   (contents of boxes 1..4)
           "... q: where C. a:"                                       answer " 3"         (the box holding C)
  TC       prompt + " cot:" + " > D B A C" per op (TC2: every 2nd op and the last) + " a:" + answer  (step-labelled)
  CL       prompt with "think:" before "a:": K' = N continuous thoughts (Coconut: the last hidden state is fed back as the
           next input embedding), then " done. a:" + answer; final answers only
  WC(k)    short-problem solver: "start: ... ops: <k' <= k ops>. think:" + k' thoughts + " done. a:" + end arrangement;
           at test the long problem is cut every k ops, each chunk's arrangement is decoded greedily and fed as the next
           start (latent history cut); the answer is read from the last arrangement
  WC0(k)   the same solver with no thoughts ("... ops: ... a:")
Compute per problem (KV cache used everywhere: each position is processed once): tokens processed (incl. latent
positions), FLOPs = sum over processed positions of (2 * non-embedding params + 4 * n_layer * d * context) plus
2 * d * vocab for every position whose logits are read, sequential forward passes, written (generated) tokens.
"""
import math
import os
import random

import numpy as np
import tiktoken
import torch
import torch.nn as nn
import torch.nn.functional as F

ENC = tiktoken.get_encoding("gpt2")
NB = int(os.environ.get("BOXES_NB", "4"))          # number of boxes (§66: 4 = S4; S5 prep: 5). Default unchanged
LET = "ABCDEFGH"[:NB]


# ---------------------------------------------------------------- task
def make_problem(rng, n, qtype=None):
    start = list(LET); rng.shuffle(start)
    ops = []
    for _ in range(n):
        i, j = sorted(rng.sample(range(NB), 2)); ops.append((i, j))
    qtype = qtype or rng.choice(["all", "where"])
    target = rng.choice(LET)
    return {"start": "".join(start), "ops": ops, "qtype": qtype, "target": target}


def apply(arr, ops):
    a = list(arr)
    for i, j in ops:
        a[i], a[j] = a[j], a[i]
    return "".join(a)


def answer_text(arr, qtype, target):
    return " " + " ".join(arr) if qtype == "all" else " " + str(arr.index(target) + 1)


def truth(p):
    return answer_text(apply(p["start"], p["ops"]), p["qtype"], p["target"])


def s_arr(arr):
    return " ".join(arr)


def s_ops(ops):
    return ", ".join(f"swap {i + 1} {j + 1}" for i, j in ops)


def s_q(p):
    return "q: all." if p["qtype"] == "all" else f"q: where {p['target']}."


def prompt(p, think=False, start=None, ops=None, q=True):
    start = p["start"] if start is None else start; ops = p["ops"] if ops is None else ops
    s = f"start: {s_arr(start)}. ops: {s_ops(ops)}."
    if q:
        s += " " + s_q(p)
    return s + (" think:" if think else " a:")


def tc_text(p, every=1):
    a = list(p["start"]); out = []
    for t, (i, j) in enumerate(p["ops"]):
        a[i], a[j] = a[j], a[i]
        if (t + 1) % every == 0 or t == len(p["ops"]) - 1:
            out.append(" > " + s_arr(a))
    return " cot:" + "".join(out) + " a:"


def tok(s):
    return ENC.encode(s)


# ---------------------------------------------------------------- model (GPT-2 small, KV cache, trainable)
def random_gpt2_sd(L, D, H, gen, vocab=50257, ctx=1024):
    """§178 FROM-SCRATCH: a GPT-2-architecture state dict at the standard GPT-2 init (HF GPT2PreTrainedModel._init_weights): Linear / Conv1D and the
    embeddings ~ N(0, 0.02), the residual projections (attn.c_proj, mlp.c_proj) ~ N(0, 0.02 / sqrt(2 L)), biases 0, LayerNorm 1 / 0. Conv1D (in, out)."""
    n = lambda *sh, std=0.02: torch.randn(*sh, generator=gen) * std  # noqa: E731
    sd = {"wte.weight": n(vocab, D), "wpe.weight": n(ctx, D), "ln_f.weight": torch.ones(D), "ln_f.bias": torch.zeros(D)}; rs = 0.02 / math.sqrt(2 * L)
    for i in range(L):
        p_ = "h.%d." % i
        sd.update({p_ + "ln_1.weight": torch.ones(D), p_ + "ln_1.bias": torch.zeros(D), p_ + "ln_2.weight": torch.ones(D), p_ + "ln_2.bias": torch.zeros(D),
                   p_ + "attn.c_attn.weight": n(D, 3 * D), p_ + "attn.c_attn.bias": torch.zeros(3 * D),
                   p_ + "attn.c_proj.weight": n(D, D, std=rs), p_ + "attn.c_proj.bias": torch.zeros(D),
                   p_ + "mlp.c_fc.weight": n(D, 4 * D), p_ + "mlp.c_fc.bias": torch.zeros(4 * D),
                   p_ + "mlp.c_proj.weight": n(4 * D, D, std=rs), p_ + "mlp.c_proj.bias": torch.zeros(D)})
    assert D % H == 0
    return sd


class GPT2KV(nn.Module):
    def __init__(self, sd, H=12):
        super().__init__()                                                  # §178: D from wte; H an argument (GPT-2: 768 / 12)
        self.L = sum(1 for k in sd if k.startswith("h.") and k.endswith(".ln_1.weight")); self.H = H; self.D = int(sd["wte.weight"].shape[1])
        self.p = nn.ParameterDict({k.replace(".", "_"): nn.Parameter(v.float().clone()) for k, v in sd.items()
                                   if not k.endswith(".attn.bias") and not k.endswith(".attn.masked_bias")})
        self.n_nonemb = sum(v.numel() for k, v in self.p.items() if k.startswith("h_") or k.startswith("ln_f"))

    def w(self, k):
        return self.p[k.replace(".", "_")]

    def embed(self, ids):
        return self.w("wte.weight")[ids]

    def forward(self, x, past=None, pos0=None, inject=None, capture=None, kv_mask=None):
        """x: (B, T, D) input embeddings appended after `past` (list per layer of (k, v)). Returns final hidden (after
        ln_f), new past. pos0 (§98 masked fork): position of x's first token when `past` is a slice of a longer cache
        (default: the cache length). §102 (all default off): inject = (i, v) adds v (B, D) to the LAST position's residual
        stream entering block i (0-based; i = 4 is "h(4)"); capture = c also returns the last position's hidden after c
        blocks (pre ln_f; c = 9 is "h(9)") as a third value; kv_mask = absolute key positions no query may attend to."""
        B, T, D = x.shape; P0 = 0 if past is None else past[0][0].shape[2]; hd = D // self.H
        p0 = P0 if pos0 is None else pos0
        h = x + self.w("wpe.weight")[p0:p0 + T][None]
        new = []; cap = None
        for i in range(self.L):
            pre = f"h.{i}."
            if inject is not None and i == inject[0]:
                h = torch.cat([h[:, :-1], (h[:, -1] + inject[1].to(h.dtype))[:, None]], 1)
            a = F.layer_norm(h, (D,), self.w(pre + "ln_1.weight"), self.w(pre + "ln_1.bias"))
            q, k, v = (a @ self.w(pre + "attn.c_attn.weight") + self.w(pre + "attn.c_attn.bias")).split(D, -1)
            q, k, v = (t.view(B, T, self.H, hd).transpose(1, 2) for t in (q, k, v))
            if past is not None:
                k = torch.cat([past[i][0], k], 2); v = torch.cat([past[i][1], v], 2)
            new.append((k, v))
            if P0 == 0 and kv_mask is None:
                o = F.scaled_dot_product_attention(q, k, v, is_causal=True)
            else:
                mask = torch.ones(T, P0 + T, dtype=torch.bool, device=x.device).tril(P0)
                if kv_mask is not None:
                    mask[:, list(kv_mask)] = False
                o = F.scaled_dot_product_attention(q, k, v, attn_mask=mask)
            h = h + o.transpose(1, 2).reshape(B, T, D) @ self.w(pre + "attn.c_proj.weight") + self.w(pre + "attn.c_proj.bias")
            a = F.layer_norm(h, (D,), self.w(pre + "ln_2.weight"), self.w(pre + "ln_2.bias"))
            m = F.gelu(a @ self.w(pre + "mlp.c_fc.weight") + self.w(pre + "mlp.c_fc.bias"), approximate="tanh")
            h = h + m @ self.w(pre + "mlp.c_proj.weight") + self.w(pre + "mlp.c_proj.bias")
            if capture is not None and i == capture - 1:
                cap = h[:, -1]
        out = F.layer_norm(h, (D,), self.w("ln_f.weight"), self.w("ln_f.bias"))
        return (out, new, cap) if capture is not None else (out, new)

    def logits(self, h):
        return h @ self.w("wte.weight").T


class Meter:
    """Per-problem compute (averaged over the batch rows, which are identical in shape)."""
    def __init__(self, m):
        self.m = m; self.tokens = 0; self.flops = 0.0; self.passes = 0; self.written = 0

    def step(self, T, ctx_before, logit_rows):
        for t in range(T):
            self.flops += 2 * self.m.n_nonemb + 4 * self.m.L * self.m.D * (ctx_before + t + 1)
        self.flops += 2 * self.m.D * 50257 * logit_rows
        self.tokens += T; self.passes += 1

    def as_dict(self):
        return {"tokens_processed": self.tokens, "flops": self.flops, "seq_passes": self.passes, "written_tokens": self.written,
                "latent_passes": 0, "gen_tokens": self.written}


def run_prefix(m, ids, past=None, meter=None, need_logits=False):
    x = m.embed(ids); ctx = 0 if past is None else past[0][0].shape[2]
    h, past = m(x, past)
    if meter:
        meter.step(ids.shape[1], ctx, 1 if need_logits else 0)
    return h, past


def latents(m, h_last, past, K, meter=None):
    """K Coconut thoughts: feed the last hidden state back as the next input embedding."""
    for _ in range(K):
        ctx = past[0][0].shape[2]
        h, past = m(h_last[:, None, :], past)
        if meter:
            meter.step(1, ctx, 0); meter.lat = getattr(meter, "lat", 0) + 1
        h_last = h[:, -1]
    return h_last, past


def greedy(m, h_last, past, n, meter=None, allowed=None):
    """Greedy-decode n tokens (allowed: optional list of token ids to restrict to)."""
    out = []
    for t in range(n):
        lg = m.logits(h_last)
        if allowed is not None:
            mask = torch.full_like(lg, float("-inf")); mask[:, allowed] = 0; lg = lg + mask
        nxt = lg.argmax(-1); out.append(nxt)
        if meter:
            meter.written += 1
            meter.flops += 2 * m.D * 50257
        if t < n - 1:
            ctx = past[0][0].shape[2]
            h, past = m(m.embed(nxt)[:, None, :], past)
            if meter:
                meter.step(1, ctx, 0)
            h_last = h[:, -1]
    return torch.stack(out, 1)


def gen_feed(m, h_last, past, n, meter=None, allowed=None):
    """Greedy-decode n tokens and feed every one of them into the cache. Returns (ids, last hidden, past)."""
    out = []
    for _ in range(n):
        lg = m.logits(h_last)
        if allowed is not None:
            mask = torch.full_like(lg, float("-inf")); mask[:, allowed] = 0; lg = lg + mask
        nxt = lg.argmax(-1); out.append(nxt)
        ctx = past[0][0].shape[2]; h, past = m(m.embed(nxt)[:, None, :], past)
        if meter:
            meter.written += 1; meter.step(1, ctx, 1)
        h_last = h[:, -1]
    return torch.stack(out, 1), h_last, past


LET_IDS = [tok(" " + c)[0] for c in LET]
DIG_IDS = [tok(" " + str(d))[0] for d in range(1, NB + 1)]


def dec_arr(ids):
    return "".join(ENC.decode([int(i)]).strip() for i in ids)


# ---------------------------------------------------------------- training losses (teacher forcing on the answer)
def tensor(rows, dev):
    return torch.tensor(rows, dtype=torch.long, device=dev)


def loss_batch(m, arm, k, batch, dev):
    """batch: list of problems with equal shapes. Returns CE loss on the answer (+ CoT text for TC)."""
    if arm in ("nc", "tc", "tc2"):
        pre = [tok(prompt(p)) for p in batch] if arm == "nc" else \
              [tok(prompt(p)[:-3] + tc_text(p, 1 if arm == "tc" else 2)) for p in batch]
        tgt = [tok(truth(p)) for p in batch]
        if arm != "nc":                                          # CoT tokens are supervised too (step-labelled)
            base = [tok(prompt(p)[:-3]) for p in batch]
            ids = tensor([a + b for a, b in zip(pre, tgt)], dev)
            h, _ = m(m.embed(ids[:, :-1]))
            lg = m.logits(h); y = ids[:, 1:].clone()
            y[:, : len(base[0]) - 1] = -100
            return F.cross_entropy(lg.reshape(-1, lg.shape[-1]), y.reshape(-1), ignore_index=-100)
        ids = tensor([a + b for a, b in zip(pre, tgt)], dev)
        h, _ = m(m.embed(ids[:, :-1])); lg = m.logits(h[:, len(pre[0]) - 1:])
        return F.cross_entropy(lg.reshape(-1, lg.shape[-1]), ids[:, len(pre[0]):].reshape(-1))
    # latent arms: cl (K' = N, question included), wc / wc0 (solver: end arrangement, no question)
    q = arm == "cl"
    if arm == "cl":
        K = len(batch[0]["ops"])
    elif arm == "wc":
        K = len(batch[0]["ops"])                                 # k' thoughts for a k'-op chunk
    else:
        K = 0
    pre = tensor([tok(prompt(p, think=K > 0, q=q)) for p in batch], dev)
    h, past = m(m.embed(pre))
    hl = h[:, -1]
    if K:
        hl, past = latents(m, hl, past, K)
        mid = tensor([tok(" done. a:")] * len(batch), dev)
        h2, past = m(m.embed(mid), past); hl = h2[:, -1]
    tgt = tensor([tok(truth(p) if q else answer_text(apply(p["start"], p["ops"]), "all", "A")) for p in batch], dev)
    x = m.embed(tgt[:, :-1])
    h3, _ = m(x, past) if tgt.shape[1] > 1 else (None, None)
    hs = torch.cat([hl[:, None]] + ([h3] if h3 is not None else []), 1)
    lg = m.logits(hs)
    return F.cross_entropy(lg.reshape(-1, lg.shape[-1]), tgt.reshape(-1))


# ---------------------------------------------------------------- inference (batch of problems with equal N, qtype)
@torch.no_grad()
def infer(m, arm, k, batch, dev, edit=None, kp=None):
    """Returns (list of answer strings, compute dict per problem). edit: for WC, {"chunk": c, "arr": [...]} replaces the
    written arrangement after chunk c by the given arrangements (per row). kp (CL only; PILOT.md K' curve): None = K' = N
    (the panel), "half" = max(1, ceil(N / 2)), "double" = 2N."""
    meter = Meter(m); B = len(batch); N = len(batch[0]["ops"]); qt = batch[0]["qtype"]
    nans = NB if qt == "all" else 1
    allowed = LET_IDS if qt == "all" else DIG_IDS
    if arm in ("nc", "cl", "tc", "tc2"):
        if arm == "cl":
            pre = tensor([tok(prompt(p, think=True)) for p in batch], dev)
            h, past = run_prefix(m, pre, meter=meter)
            Kp = N if kp is None else max(1, math.ceil(N / 2)) if kp == "half" else 2 * N if kp == "double" else None
            assert Kp is not None, kp
            hl, past = latents(m, h[:, -1], past, Kp, meter)
            mid = tensor([tok(" done. a:")] * B, dev); h, past = run_prefix(m, mid, past, meter, True); hl = h[:, -1]
        elif arm == "nc":
            pre = tensor([tok(prompt(p)) for p in batch], dev); h, past = run_prefix(m, pre, meter=meter, need_logits=True); hl = h[:, -1]
        else:
            pre = tensor([tok(prompt(p)[:-3] + " cot:") for p in batch], dev); h, past = run_prefix(m, pre, meter=meter, need_logits=True)
            nstates = N if arm == "tc" else math.ceil(N / 2)
            hl = h[:, -1]
            gt = tok(" >")
            for s_ in range(nstates):                            # each state: " >" (forced) then 4 greedy letters, fed back
                ctx = past[0][0].shape[2]; h, past = m(m.embed(tensor([gt] * B, dev)), past); meter.step(1, ctx, 1)
                meter.written += 1; hl = h[:, -1]
                _, hl, past = gen_feed(m, hl, past, NB, meter, LET_IDS)
            ctx = past[0][0].shape[2]; h, past = m(m.embed(tensor([tok(" a:")] * B, dev)), past)
            meter.step(len(tok(" a:")), ctx, 1); hl = h[:, -1]
        ans = greedy(m, hl, past, nans, meter, allowed)
        texts = [" " + " ".join(ENC.decode([int(t)]).strip() for t in row) for row in ans]
        c = meter.as_dict(); c["latent_passes"] = getattr(meter, "lat", 0)
        valid = [{"valid_final": float(len(set(t.split())) == NB)} if qt == "all" else {} for t in texts]
        return texts, c, valid
    # WC / WC0: chunked solver
    arrs = [p["start"] for p in batch]
    chunks = [list(range(s, min(s + k, N))) for s in range(0, N, k)]
    nvalid = [0] * B
    for ci, ch in enumerate(chunks):
        sub = [dict(p, start=a, ops=[p["ops"][t] for t in ch]) for p, a in zip(batch, arrs)]
        K = len(ch) if arm == "wc" else 0
        pre = tensor([tok(prompt(sp, think=K > 0, q=False)) for sp in sub], dev)
        h, past = run_prefix(m, pre, meter=meter, need_logits=K == 0); hl = h[:, -1]
        if K:
            hl, past = latents(m, hl, past, K, meter)
            mid = tensor([tok(" done. a:")] * B, dev); h, past = run_prefix(m, mid, past, meter, True); hl = h[:, -1]
        out = greedy(m, hl, past, NB, meter, LET_IDS)
        arrs = [dec_arr(r) for r in out]                       # vocabulary-only decode: NOT forced to a permutation
        nvalid = [v + (len(set(a)) == NB) for v, a in zip(nvalid, arrs)]
        if edit is not None and ci == edit["chunk"]:
            arrs = list(edit["arr"])
    # "where" is read off the last written arrangement; a target missing from it (invalid state) answers "0" (wrong)
    texts = [(" " + str(a.index(p["target"]) + 1) if p["target"] in a else " 0") if qt == "where" else " " + " ".join(a)
             for a, p in zip(arrs, batch)]
    c = meter.as_dict(); c["latent_passes"] = getattr(meter, "lat", 0)
    valid = [{"valid_final": float(len(set(a)) == NB), "chunk_valid_share": v / len(chunks)} for a, v in zip(arrs, nvalid)]
    return texts, c, valid
