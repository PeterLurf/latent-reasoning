"""THEORY §170 NESTED (eed3f25a; scorer theory/score_s170.py): Feng et al. 2305.15408's Arithmetic(n, 11), Alg. 1 - data, rendering, evaluation, CoT.
Generator: t ~ U(Z11) is the expression; n times: a uniform random number position, an operator uniformly from + - * /, and (t1, t2) uniformly among the
pairs with o(t1, t2) = that number (t2 != 0 for /; / = multiplication by the modular inverse); the number becomes "t1 o t2". Brackets exactly where
precedence or left associativity needs them (a child of lower precedence, or a right child of equal precedence). Spaced tokens: " ( 3 + 10 ) * 4 =".
TEXT-COT (Feng's format): each step reduces the leftmost operation evaluable under precedence and brackets (a node whose operands are both numbers;
re-rendering drops a bracket around the single number in the same step): "e1 = e2 = ... = t"."""
import os
import re

import numpy as np
import tiktoken

P = 11
OPS = ["+", "-", "*", "/"]
PREC = {"+": 1, "-": 1, "*": 2, "/": 2}
ENC = tiktoken.get_encoding("gpt2")
VOCAB = [" %d" % v for v in range(P)] + [" " + o for o in OPS] + [" (", " )", " =", " ."]
TOK = {w: ENC.encode(w) for w in VOCAB}
assert all(len(t) == 1 for t in TOK.values()) and all(ENC.decode(t) == w for w, t in TOK.items()), "§170: every symbol must be one GPT-2 token"
TID = {w: t[0] for w, t in TOK.items()}; NUM_IDS = np.array([TID[" %d" % v] for v in range(P)])
INV = {v: pow(v, P - 2, P) for v in range(1, P)}


def apply(o, a, b):
    return (a + b) % P if o == "+" else (a - b) % P if o == "-" else (a * b) % P if o == "*" else (a * INV[b]) % P


PAIRS = {(o, v): [(a, b) for a in range(P) for b in range(P) if not (o == "/" and b == 0) and apply(o, a, b) == v] for o in OPS for v in range(P)}


class Node:
    __slots__ = ("op", "l", "r", "v")

    def __init__(self, v=None, op=None, l=None, r=None):
        self.v, self.op, self.l, self.r = v, op, l, r


def generate(rng, n):
    """Alg. 1: returns (root, t)."""
    t = int(rng.integers(0, P)); root = Node(v=t); leaves = [root]
    for _ in range(n):
        i = int(rng.integers(0, len(leaves))); leaf = leaves.pop(i); o = OPS[int(rng.integers(0, 4))]; prs = PAIRS[(o, leaf.v)]; a, b = prs[int(rng.integers(0, len(prs)))]
        leaf.op, leaf.l, leaf.r, leaf.v = o, Node(v=a), Node(v=b), None; leaves.insert(i, leaf.r); leaves.insert(i, leaf.l)
    return root, t


def render(nd, parent=None, right=False):
    """minimal-bracket rendering -> list of symbols (" 3", " +", " (" ...)."""
    if nd.op is None:
        return [" %d" % nd.v]
    s = render(nd.l, nd.op, False) + [" " + nd.op] + render(nd.r, nd.op, True)
    if parent is not None and (PREC[nd.op] < PREC[parent] or (right and PREC[nd.op] == PREC[parent])):
        s = [" ("] + s + [" )"]
    return s


def value(nd):
    return nd.v if nd.op is None else apply(nd.op, value(nd.l), value(nd.r))


def depth(syms):
    d = m = 0
    for s in syms:
        d += s == " ("; d -= s == " )"; m = max(m, d)
    return m


def eval_tokens(syms):
    """an INDEPENDENT Z11 evaluator: shunting-yard over the rendered symbols (precedence, left associativity, brackets)."""
    out, st = [], []
    for s in syms:
        w = s.strip()
        if w.isdigit():
            out.append(int(w))
        elif w in PREC:
            while st and st[-1] in PREC and PREC[st[-1]] >= PREC[w]:
                b, a = out.pop(), out.pop(); out.append(apply(st.pop(), a, b))
            st.append(w)
        elif w == "(":
            st.append(w)
        elif w == ")":
            while st[-1] != "(":
                b, a = out.pop(), out.pop(); out.append(apply(st.pop(), a, b))
            st.pop()
    while st:
        b, a = out.pop(), out.pop(); out.append(apply(st.pop(), a, b))
    assert len(out) == 1
    return out[0]


def _leftmost_ready(nd, path=()):
    """the leftmost node (in rendering order) whose operands are both numbers."""
    if nd.op is None:
        return None
    r = _leftmost_ready(nd.l, path + ("l",))
    if r is not None:
        return r
    if nd.l.op is None and nd.r.op is None:
        return path
    return _leftmost_ready(nd.r, path + ("r",))


def _copy(nd):
    return Node(v=nd.v) if nd.op is None else Node(op=nd.op, l=_copy(nd.l), r=_copy(nd.r))


def cot_steps(root):
    """Feng's CoT: the list of expressions e1 (= the input) .. t, each the previous with its leftmost evaluable operation reduced."""
    nd = _copy(root); steps = [render(nd)]
    while nd.op is not None:
        path = _leftmost_ready(nd); tgt = nd
        for p in path:
            tgt = getattr(tgt, p)
        tgt.v = apply(tgt.op, tgt.l.v, tgt.r.v); tgt.op = tgt.l = tgt.r = None; steps.append(render(nd))
    return steps


def ids(syms):
    return [TID[s] for s in syms]


def self_check(n_items=100_000, seed=17000):
    """the generator gate: the independent evaluator re-derives t on n_items samples (n ~ U{1..16}); returns (ok share, n)."""
    rng = np.random.default_rng(seed); ok = 0
    for _ in range(n_items):
        root, t = generate(rng, int(rng.integers(1, 17))); syms = render(root); ok += (eval_tokens(syms) == t) and (value(root) == t)
        if _ < 2000:                                                        # the CoT ends at t and every step evaluates to t
            st = cot_steps(root); assert st[-1] == [" %d" % t] and all(eval_tokens(s) == t for s in st), "cot"
    return ok / n_items, n_items


# ====================================================================================================== §170 runs (DIRECT / INJECT / TEXT-COT)
import argparse  # noqa: E402
import json  # noqa: E402
import math  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
os.environ.setdefault("BOXES_NB", "5")
import torch  # noqa: E402
import torch.nn.functional as Fn  # noqa: E402
EOT = 50256


def test_set(per_n=1000, n_max=16, seed=17100):
    """1,000 items per n in 1..16 (fixed seed): list of dicts {n, syms, t, depth, root}."""
    rng = np.random.default_rng(seed); out = []
    for n in range(1, n_max + 1):
        for _ in range(per_n):
            r, t = generate(rng, n); s = render(r); out.append({"n": n, "syms": s, "t": t, "depth": depth(s), "root": r})
    return out


def train_items(rng, bs, n_max, excl):
    out = []
    while len(out) < bs:
        n_ = int(rng.integers(1, n_max + 1)); r, t = generate(rng, n_); s = render(r)   # (the same draws as before; n_ kept for §177 (f)'s buckets)
        if tuple(s) not in excl:
            out.append({"syms": s, "t": t, "root": r, "n": n_})
    return out


def pad(seqs, fill=EOT):
    T = max(len(q) for q in seqs); ids = np.full((len(seqs), T), fill); m = np.zeros((len(seqs), T), bool)
    for r, q in enumerate(seqs):
        ids[r, :len(q)] = q; m[r, :len(q)] = True
    return ids, m


def cot_ids(root):
    st = cot_steps(root); out = []
    for k, s in enumerate(st[1:]):
        out += ids(s) + ([TID[" ="]] if k < len(st) - 2 else [])
    return out + [EOT]


# ---- §175 STEP-AUX (Theory 8965745e): a read-only step decoder after each think pass ----
STEP_ID, COLON_ID = ENC.encode(" Step"), ENC.encode(" :")
assert len(STEP_ID) == 1 and len(COLON_ID) == 1
STEP_ID, COLON_ID = STEP_ID[0], COLON_ID[0]


def pass_tok(t):
    tk = ENC.encode(" %d" % t); assert len(tk) == 1; return tk[0]


PASS_TOKS = frozenset(pass_tok(t) for t in range(0, 65))      # §187: every pass-index token the aux prompt could carry


def _render_pos(nd, tgt, parent=None, right=False):
    """render() plus the symbol index of node tgt in it (None if tgt is not in this subtree)."""
    if nd.op is None:
        return [" %d" % nd.v], (0 if nd is tgt else None)
    ls, lp = _render_pos(nd.l, tgt, nd.op, False); rs, rp = _render_pos(nd.r, tgt, nd.op, True)
    sy = ls + [" " + nd.op] + rs; po = lp if lp is not None else (len(ls) + 1 + rp if rp is not None else None)
    if parent is not None and (PREC[nd.op] < PREC[parent] or (right and PREC[nd.op] == PREC[parent])):
        sy = [" ("] + sy + [" )"]; po = None if po is None else po + 1
    return sy, po


def aux_steps(root):
    """§175: per reduction t = 1..n, (e_{t+1} as symbols = cot_steps(root)[t], the index of the newly reduced value in it)."""
    nd = _copy(root); out = []
    while nd.op is not None:
        path = _leftmost_ready(nd); tgt = nd
        for p_ in path:
            tgt = getattr(tgt, p_)
        tgt.v = apply(tgt.op, tgt.l.v, tgt.r.v); tgt.op = tgt.l = tgt.r = None; out.append(_render_pos(nd, tgt))
    return out


def aux_of(it):
    if "aux" not in it:
        it["aux"] = aux_steps(it["root"])
    return it["aux"]


class InjectN(torch.nn.Module):
    """§169's inject harness on a variable-length text: think = [EOT, expr, " ."] (right-padded, padded writes masked); decoder = [EOT, expr, " ="] -> the
    answer token (read-only)."""
    def __init__(self, g, layer=6, write="top", h_add=6, h_del=6, add_norm=None):
        super().__init__(); import boxes.deltamem as DM; self.DM = DM; self.g = g; self.mem = DM.DeltaMem(g, layer, write, h_add, h_del, add_norm)
        self.nopass = False                                                 # §187 AUX-NOPASS: the aux prompt without the pass token (set from args)

    def aux_prompt(self, t):
        """§175's aux prompt [EOT, " Step", " t", " :"]; §187 (--aux_nopass): [EOT, " Step", " :"] - no pass token."""
        if self.nopass:
            pre = [EOT, STEP_ID, COLON_ID]; assert not any(tk in PASS_TOKS for tk in pre), "§187: a pass token in the aux prompt"
            return pre
        return [EOT, STEP_ID, pass_tok(t), COLON_ID]

    def think_inputs(self, items, dev):
        ids_, m_ = pad([[EOT] + ids(it["syms"]) + [TID[" ."]] for it in items]); return torch.tensor(ids_, device=dev), torch.tensor(m_, device=dev)

    def write(self, S, x, mask, h_low=None):
        return self.DM.gpt_forward_mem(self.g, self.g.embed(x), self.mem, S, mask=mask, h_low=h_low)[1]

    def lower(self, x):
        """--cache_lower (Theory / Audit 2026-10-13): blocks 0..layer-1 on the think input, once per batch (every pass sees the identical input)."""
        return self.DM.gpt_lower(self.g, self.g.embed(x), self.mem.layer)

    def think(self, S, x, mask, K, skip=(), override=None, ckpt=False, h_low=None):
        from torch.utils.checkpoint import checkpoint
        for t in range(1, K + 1):
            if t not in skip:
                S = checkpoint(self.write, S, x, mask, h_low, use_reentrant=False) if (ckpt and torch.is_grad_enabled()) else self.write(S, x, mask, h_low)
            if override is not None and override[0] == t:
                S = override[1]
        return S

    def dec_logits(self, S, items, dev):
        from boxes.deltas5 import fwd_read
        seqs = [[EOT] + ids(it["syms"]) + [TID[" ="]] for it in items]; ids_, _ = pad(seqs); x = torch.tensor(ids_, device=dev)
        h = fwd_read(self.g, self.g.embed(x), self.mem, S); pos = torch.tensor([len(q) - 1 for q in seqs], device=dev)
        return self.g.logits(h[torch.arange(len(seqs), device=dev), pos]).float()   # (B, V) at " ="

    def aux_logits(self, S, items, t, dev, hold=False):
        """§175: the SAME trunk, read-only (fwd_read: the read on S, no write), over [EOT, " Step", " t", " :"] + e_{t+1} (teacher-forced). It sees no
        problem text and is never fed back. -> (logits (b, L, V) predicting e_{t+1} then EOT, targets (b, L), -100 = padding).
        §182 HOLD (hold=True): for a pass t > n the target is e_{n+1} (step n's target string, the final value)."""
        from boxes.deltas5 import fwd_read
        pre = self.aux_prompt(t); seqs, tg = [], []
        for it in items:
            n_ = len(aux_of(it)); assert t <= n_ or hold, "§175: no aux target past the last reduction"
            tgt = ids(aux_of(it)[min(t, n_) - 1][0]) + [EOT]; seqs.append(pre + tgt[:-1]); tg.append(tgt)
        x_, _ = pad(seqs); y_, _ = pad(tg, -100); x = torch.tensor(x_, device=dev); y = torch.tensor(y_, device=dev)
        assert x.shape[1] == len(pre) + y.shape[1] - 1
        h = fwd_read(self.g, self.g.embed(x), self.mem, S)
        return self.g.logits(h[:, len(pre) - 1:]).float(), y

    @torch.no_grad()
    def aux_greedy(self, S, t, L):
        """§175 eval: greedy L tokens after [EOT, " Step", " t", " :"] reading S -> (b, L) token ids."""
        from boxes.deltas5 import fwd_read
        pre = self.aux_prompt(t); x = torch.tensor([pre] * S.shape[0], device=S.device)
        for _ in range(L):
            nt = self.g.logits(fwd_read(self.g, self.g.embed(x), self.mem, S)[:, -1]).float().argmax(-1); x = torch.cat([x, nt[:, None]], 1)
        return x[:, len(pre):].cpu().numpy()


class AnnealGate:
    """note 196-1 entry-gated --anneal (Theory): pre-final stages advance after `need` consecutive bin means of the training loss < thr (bins aligned to
    steps bin*b+1 .. bin*(b+1), over the stage's own steps; non-finite steps skipped), or after max_steps in the stage ('fallback'); the final stage runs
    exactly final_len steps from its first step s_full. update(step, loss) is called after every training step; -> (new stage, reason, bin mean) or None.
    state() / load() round-trip the whole gate (partial bin, consecutive count) for --resume."""
    def __init__(self, n_stages, thr, need, max_steps, final_len, bin_=1000):
        self.n_stages, self.thr, self.need, self.max_steps, self.final_len, self.bin = n_stages, thr, need, max_steps, final_len, bin_
        self.stage, self.stage_start, self.bin_sum, self.bin_n, self.consec, self.s_full = 0, 1, 0.0, 0, 0, None

    def final(self):
        return self.stage == self.n_stages - 1

    def end(self):
        return None if self.s_full is None else self.s_full + self.final_len - 1

    def update(self, step, loss):
        if self.final():
            return None
        if loss is not None and math.isfinite(loss):
            self.bin_sum += loss; self.bin_n += 1
        if step % self.bin:
            return None
        mean = self.bin_sum / self.bin_n if self.bin_n else float("inf"); self.bin_sum, self.bin_n = 0.0, 0
        self.consec = self.consec + 1 if mean < self.thr else 0
        reason = "gate" if self.consec >= self.need else ("fallback" if step - self.stage_start + 1 >= self.max_steps else None)
        if reason is None:
            return None
        self.stage += 1; self.stage_start = step + 1; self.consec = 0
        if self.final():
            self.s_full = step + 1
        return self.stage, reason, mean

    def state(self):
        return dict(vars(self))

    def load(self, st):
        for k_, v_ in st.items():
            setattr(self, k_, v_)


def grokfast_ema(named, ema, alpha, lamb, norms=False):
    """§196 GROKFAST (ironjr/grokfast gradfilter_ema; Theory 78487d7a): per parameter h <- alpha * h + (1 - alpha) * g, h initialised from the first
    gradient (h = g at step 1), then g <- g + lamb * h in place on p.grad. Called after backward, before clip_grad_norm_. norms -> (||g|| before the
    filter, ||lamb * h||) as global L2 norms (one sync), else (None, None)."""
    g2, s2 = [], []
    for n_, p_ in named:
        if p_.grad is None:
            continue
        g_ = p_.grad.detach()
        if norms:
            g2.append(g_.float().pow(2).sum())
        h_ = ema.get(n_, g_)                                                # the reference's arithmetic exactly (init h = g, then the update also at step 1)
        ema[n_] = h_ * alpha + g_ * (1 - alpha)
        if norms:
            s2.append((ema[n_] * lamb).float().pow(2).sum())
        p_.grad.add_(ema[n_] * lamb)
    if not norms or not g2:
        return None, None
    return float(torch.stack(g2).sum().sqrt()), float(torch.stack(s2).sum().sqrt())


def kmatch_loss(m, items, kitem, dev, ac, masked=True, cache=False):
    """§177 (f) (notes 177-4 / 177-5): the answer CE (mean over items) with item i thinking kitem[i] passes -> (loss, final S in item order).
    masked (the training form): ONE batch for K_max passes; after pass t each item's state is the new one only while t <= its K (a state-level select,
    Audit: the gated-delta decay / gamma / fade could move S on a pass with no token writes), so S is frozen at its own K and the gradient flows through
    the active branch only. bucketed (the reference): items grouped by K, each group run separately (§177 as first built)."""
    tgt = torch.tensor(NUM_IDS[[it["t"] for it in items]], device=dev)
    if masked:
        x, msk = m.think_inputs(items, dev); kv = torch.tensor(np.asarray(kitem), device=dev)
        with ac():
            S = m.mem.zero_state(len(items), dev); hl = m.lower(x) if cache else None
            for t in range(1, int(max(kitem)) + 1):
                S = torch.where((kv >= t)[:, None, None, None], m.write(S, x, msk, hl), S)
            lg = m.dec_logits(S, items, dev)
        return Fn.cross_entropy(lg, tgt), S
    tot, Sall = 0.0, [None] * len(items)
    for k_ in sorted(set(int(k) for k in kitem)):
        ix = [i for i, k in enumerate(kitem) if int(k) == k_]; sub = [items[i] for i in ix]; x, msk = m.think_inputs(sub, dev)
        with ac():
            S = m.think(m.mem.zero_state(len(sub), dev), x, msk, k_); lg = m.dec_logits(S, sub, dev)
        tot = tot + Fn.cross_entropy(lg, tgt[ix]) * (len(sub) / len(items))
        for r_, i in enumerate(ix):
            Sall[i] = S[r_]
    return tot, torch.stack(Sall)


AUX_W = (0.368, 0.582, 0.821, 1.131, 1.576, 2.301, 3.733, 8.0)            # §184 (c342e51c): w_t = E_bar / E_t, E_t = (1/8) sum_{n=t}^{8} 1/n
_E = [sum(1.0 / n for n in range(t, 9)) / 8 for t in range(1, 9)]
assert all(abs(w - sum(_E) / 8 / e) < 1e-3 for w, e in zip(AUX_W, _E)) and abs(sum(e * w for e, w in zip(_E, AUX_W)) - sum(_E)) < 1e-3, "§184: the weight table"


def kmatch_aux_loss(m, items, kitem, dev, ac, hold=False, reweight=False, wrec=None, cache=False):
    """§182 WINDOW / HOLD: note 177-5's masked single batch (item i thinks kitem[i] passes; S frozen after its K) + §175's aux CE (token mean per pass,
    mean over each item's REAL steps t <= n, then over items: §175's weighting, identical in every cell). HOLD (Audit 8e20d709 review): the hold passes
    n < t <= K_i (target e_{n+1}) form a SEPARATE term hold_aux = mean over items of the mean over their hold passes (0 without hold), so the real-step
    weight is not diluted. -> (answer CE, aux, hold_aux, S); the caller adds lambda * (aux + hold_aux).
    §188 (5b2ebd2e): reweight -> each REAL-step CE (t <= n) times AUX_W[t-1] inside the per-item mean, as loss_items does (§184); wrec (a list) collects
    the weight of every kept real-step term (the run's step-1 tripwire)."""
    tgt = torch.tensor(NUM_IDS[[it["t"] for it in items]], device=dev); x, msk = m.think_inputs(items, dev); kv = torch.tensor(np.asarray(kitem), device=dev)
    per = [[] for _ in items]; perh = [[] for _ in items]
    with ac():
        S = m.mem.zero_state(len(items), dev); hl = m.lower(x) if cache else None
        for t in range(1, int(max(kitem)) + 1):
            S = torch.where((kv >= t)[:, None, None, None], m.write(S, x, msk, hl), S)
            idx = [i for i, it in enumerate(items) if t <= len(aux_of(it)) or (hold and t <= int(kitem[i]))]
            if idx:
                lg_a, y_a = m.aux_logits(S[idx], [items[i] for i in idx], t, dev, hold=hold)
                ce = Fn.cross_entropy(lg_a.transpose(1, 2), y_a, ignore_index=-100, reduction="none").sum(1) / (y_a != -100).sum(1)
                for r_, i in enumerate(idx):
                    if t <= len(aux_of(items[i])):
                        w_ = AUX_W[t - 1] if reweight else 1.0                     # §188: w_t on the real steps only (hold terms: §188 refuses --aux_hold)
                        per[i].append(ce[r_] * w_ if reweight else ce[r_])
                        if wrec is not None:
                            wrec.append(w_)
                    else:
                        perh[i].append(ce[r_])
        lg = m.dec_logits(S, items, dev)
    aux = torch.stack([torch.stack(p_).mean() for p_ in per if p_]).mean()
    hold_aux = torch.stack([torch.stack(p_).mean() for p_ in perh if p_]).mean() if any(perh) else aux.new_zeros(())
    return Fn.cross_entropy(lg, tgt), aux, hold_aux, S


def ans_token_acc(lg, items):
    return (lg[:, NUM_IDS].argmax(-1).cpu().numpy() == np.array([it["t"] for it in items])), lg.argmax(-1).cpu().numpy()



def make_trunk(a, dev):
    """the GPT-2 trunk: pretrained GPT-2 small (§170), or for --scratch 'L,D,H' (§178) a RANDOM-INIT GPT-2 architecture (core.random_gpt2_sd under the
    run's seed; GPT-2 tokenizer / vocab / 1024 positions). The local memory cap is applied either way. a: the run's args (dict)."""
    from boxes import s5
    if not a.get("scratch"):
        return s5.load_gpt2(dev)
    from boxes import core as bc
    try:
        from boxes import memcap
        memcap.apply(dev)
    except ImportError:
        pass
    L, D, H = (int(x) for x in a["scratch"].split(",")); gen = torch.Generator().manual_seed(17800 + int(a.get("seed", 1)))
    return bc.GPT2KV(bc.random_gpt2_sd(L, D, H, gen), H).to(dev)


def rs_run(g, x, pos, past, kvalid, mem=None, S=None, write=False):
    """§198 (c) READ-SLOTS forward (after readslots171.run): x (B, T, D) input embeddings at absolute positions pos (B, T); past = per-layer (k, v)
    (B, H, P0, hd) of the encoded input or None; kvalid (B, P0 + T) bool = the keys a query may see (past: the row's real input tokens; own: all), with
    causal order among this call's own tokens. mem / S: the read on S entering block mem.layer; write: §155's top writes from these T positions.
    -> (hidden after ln_f, per-layer (k, v) of this call's own tokens INCLUDING past, S_new)."""
    import boxes.deltamem as DM
    B, T, D = x.shape; hd = D // g.H; P0 = 0 if past is None else past[0][0].shape[2]; h = x + g.w("wpe.weight")[pos]; h6 = None; kv = []
    own = torch.ones(T, T, dtype=torch.bool, device=x.device).tril()
    allow = torch.cat([kvalid[:, None, :P0].expand(B, T, P0), own[None].expand(B, T, T) & kvalid[:, None, P0:]], 2)[:, None]   # (B, 1, T, P0 + T)
    for i in range(g.L):
        if mem is not None and i == mem.layer:
            h6 = h; h = DM.read_fixed(mem, h, S)
        pre = f"h.{i}."
        a_ = Fn.layer_norm(h, (D,), g.w(pre + "ln_1.weight"), g.w(pre + "ln_1.bias"))
        q, k, v = (a_ @ g.w(pre + "attn.c_attn.weight") + g.w(pre + "attn.c_attn.bias")).split(D, -1)
        q, k, v = (t_.view(B, T, g.H, hd).transpose(1, 2) for t_ in (q, k, v))
        if past is not None:
            k = torch.cat([past[i][0].to(k.dtype), k], 2); v = torch.cat([past[i][1].to(v.dtype), v], 2)
        kv.append((k, v))
        o = Fn.scaled_dot_product_attention(q, k, v, attn_mask=allow)
        h = h + o.transpose(1, 2).reshape(B, T, D) @ g.w(pre + "attn.c_proj.weight") + g.w(pre + "attn.c_proj.bias")
        a_ = Fn.layer_norm(h, (D,), g.w(pre + "ln_2.weight"), g.w(pre + "ln_2.bias"))
        mm = Fn.gelu(a_ @ g.w(pre + "mlp.c_fc.weight") + g.w(pre + "mlp.c_fc.bias"), approximate="tanh")
        h = h + mm @ g.w(pre + "mlp.c_proj.weight") + g.w(pre + "mlp.c_proj.bias")
    S_new = DM.write_seq(mem, h6, h, S) if write else None
    return Fn.layer_norm(h, (D,), g.w("ln_f.weight"), g.w("ln_f.bias")), kv, S_new


class RSEnc:
    """§198 (c): one batch's encoded input (per-layer KV as a tuple: no pass can extend it), real-token mask and lengths."""
    def __init__(self, kv, valid, L):
        self.kv, self.valid, self.L = tuple(kv), valid, L


class ReadSlotsN(InjectN):
    """§198 (c) READ-SLOTS on nested (port of boxes/readslots171.ReadSlots; Theory e69bc32a): the input [EOT, expr] is encoded ONCE per batch with no
    memory read (think_inputs; the RSEnc is cached on the model and reused by every slot pass and the decoder - n_encode counts encodes); a think pass =
    M learned slot tokens (wte(' .') + N(0, 0.02^2)) after each row's own input (positions L_i .. L_i + M - 1), attending to that row's real input
    tokens and causally to the slots, the read on the pass-start state entering mem.layer and the top writes from the slot positions (a fresh slot cache
    per pass; no pass token anywhere in the slot input); the decoder = ' =' at position L_i after the input KV, reading the memory, seeing no slot. The
    step aux decoder is InjectN's (memory only, no problem text). K' = 0: no slot pass, the decoder reads the zero memory."""
    def __init__(self, g, layer=6, write="top", h_add=6, h_del=6, add_norm=None, n_slots=8):
        super().__init__(g, layer, write, h_add, h_del, add_norm); assert write == "top"
        with torch.no_grad():
            e = g.w("wte.weight")[TID[" ."]].float()
        self.slots = torch.nn.Parameter(e[None].repeat(n_slots, 1) + 0.02 * torch.randn(n_slots, e.shape[0], device=e.device))
        self._enc_items, self._enc = None, None; self.n_encode = 0; self.n_slot_pass = 0

    def encode(self, items, dev):
        ids_, m_ = pad([[EOT] + ids(it["syms"]) for it in items]); x = torch.tensor(ids_, device=dev); valid = torch.tensor(m_, device=dev)
        P0 = x.shape[1]; pos = torch.arange(P0, device=dev)[None].expand(len(items), P0)
        _, kv, _ = rs_run(self.g, self.g.embed(x), pos, None, valid); self.n_encode += 1
        return RSEnc(kv, valid, valid.sum(1))

    def think_inputs(self, items, dev):
        enc = self.encode(items, dev); self._enc_items, self._enc = items, enc; return enc, enc.valid

    def lower(self, x):
        raise AssertionError("--cache_lower does not apply to --arm readslots")

    def write(self, S, enc, mask, h_low=None):
        assert h_low is None and isinstance(enc, RSEnc) and S.shape[0] == enc.valid.shape[0]
        B, M = S.shape[0], self.slots.shape[0]; P0 = enc.valid.shape[1]; dev = S.device
        pos = enc.L[:, None] + torch.arange(M, device=dev)[None]; kvalid = torch.cat([enc.valid, torch.ones(B, M, dtype=torch.bool, device=dev)], 1)
        _, kv2, S2 = rs_run(self.g, self.slots[None].expand(B, -1, -1).to(self.g.w("wte.weight").dtype), pos, enc.kv, kvalid, self.mem, S, write=True)
        assert kv2[0][0].shape[2] == P0 + M and enc.kv[0][0].shape[2] == P0     # the slot KV lives only in kv2, dropped here
        self.n_slot_pass += 1; return S2

    def dec_logits(self, S, items, dev):
        enc = self._enc if (items is self._enc_items and self._enc is not None and self._enc.valid.shape[0] == S.shape[0]) else self.encode(items, dev)
        B = S.shape[0]; toks = torch.full((B, 1), TID[" ="], device=dev); kvalid = torch.cat([enc.valid, torch.ones(B, 1, dtype=torch.bool, device=dev)], 1)
        h, _, _ = rs_run(self.g, self.g.embed(toks), enc.L[:, None], enc.kv, kvalid, self.mem, S)
        return self.g.logits(h[:, 0]).float()


def read_parts(mem, h6, S):
    """§199 CSR (Theory 199-A): the memory read's additive and delta contributions to the residual, (R_add, R_del) each (B, T, 768), the same math
    as deltamem.read_fixed without the W_o bias: read_fixed(mem, h6, S) - h6 == R_add + R_del + fade * b_o."""
    import boxes.deltamem as DM
    H_ADD, H_DEL = mem.h_add, mem.h_del
    with torch.autocast("cuda", enabled=False):
        B, T, D = h6.shape; a_ = mem.ln(h6.float()); q = mem.qkv(a_)[..., :D].view(B, T, H_ADD + H_DEL, DM.DH)
        oa = torch.exp(mem.s_add) * DM.add_read(mem, Fn.elu(q[:, :, :H_ADD]) + 1, S[:, :H_ADD].float(), DM.state_z(mem, S))
        od = torch.exp(mem.s_del) * torch.einsum("bhvk,bthk->bthv", S[:, H_ADD:H_ADD + H_DEL].float(), Fn.normalize(q[:, :, H_ADD:], dim=-1))
        W = mem.wo.weight; na = H_ADD * DM.DH
        return mem.fade * (oa.reshape(B, T, -1) @ W[:, :na].T), mem.fade * (od.reshape(B, T, -1) @ W[:, na:].T)


def csr_lams(Rs, msk, eps0=1e-3):
    """§199: Rs = [R_0 .. R_K] (B, T, 768); msk (B, T) real tokens -> lambda (B, K - 1), lambda[:, t - 1] = log d_t - log d_{t-1} (t = 1 .. K - 1),
    d_t = sqrt(||R_{t+1} - R_t||^2 + eps0^2 ||R_t||^2 + 1e-12) over the item's real tokens x 768."""
    mk = msk[:, :, None].to(Rs[0].dtype); K = len(Rs) - 1
    d = torch.stack([torch.sqrt(((Rs[t + 1] - Rs[t]) * mk).pow(2).sum((1, 2)) + eps0 ** 2 * (Rs[t] * mk).pow(2).sum((1, 2)) + 1e-12) for t in range(K)], 1)
    return torch.log(d[:, 1:]) - torch.log(d[:, :-1])


def csr_terms(lam, ns, K, lam_min, lam_post, tau):
    """§199: per item pre = mean_{t in [2, min(n-1, K-1)]} tau softplus((lam_min - lam_t) / tau) (n >= 3), post = mean_{t in [n, K-1]} tau softplus((lam_t - lam_post) / tau)
    (n <= 7); each only where its range is non-empty (lam has K - 1 columns: t = 1 .. K - 1); csr = mean over items of (pre + post) -> csr (scalar)."""
    tot = []
    for b, n in enumerate(ns):
        v = lam.new_zeros(())
        if n >= 3 and min(n - 1, K - 1) >= 2:
            v = v + (tau * Fn.softplus((lam_min - lam[b, 1:min(n - 1, K - 1)]) / tau)).mean()
        if n <= 7 and K - 1 >= n:
            v = v + (tau * Fn.softplus((lam[b, n - 1:K - 1] - lam_post) / tau)).mean()
        tot.append(v)
    return torch.stack(tot).mean()


def csr_item_stats(lam, ns, K):
    """§199 log fields: per item the mean lambda over t in [2, min(5, n-1, K-1)] (n >= 3) and over t in [n, K-1] (n <= 7), non-empty ranges only -> (pre list, post list)."""
    pre, post = [], []
    for b, n in enumerate(ns):
        if n >= 3 and min(5, n - 1, K - 1) >= 2:
            pre.append(float(lam[b, 1:min(5, n - 1, K - 1)].mean()))
        if n <= 7 and K - 1 >= n:
            post.append(float(lam[b, n - 1:K - 1].mean()))
    return pre, post


def mem_geometry(a):
    """(memory layer, additive heads, delta heads): §170 = (6, 6, 6); §198 --mem_layer l -> (l, 6, 6) on the pretrained trunk; §178 scratch 'L,D,H'
    = (L // 2, D / 128, D / 128) (DH 64)."""
    if not a.get("scratch"):
        return int(a.get("mem_layer") or 6), 6, 6
    L, D, _ = (int(x) for x in a["scratch"].split(",")); assert D % 128 == 0
    return L // 2, D // 128, D // 128


def reductions(root):
    """the values of Feng's CoT reductions in cot_steps' (leftmost-handle) order: v_1 .. v_n."""
    nd = _copy(root); vals = []
    while nd.op is not None:
        path = _leftmost_ready(nd); tgt = nd
        for p_ in path:
            tgt = getattr(tgt, p_)
        tgt.v = apply(tgt.op, tgt.l.v, tgt.r.v); tgt.op = tgt.l = tgt.r = None; vals.append(tgt.v)
    return vals


def _mem_read(mem, x, S):
    """read_fixed's reads at one position per row (as boxes/halt173.read_vec): x (b, D) residual entering the read, S -> (b, 768) [g_add read_add || g_del read_del]."""
    import torch.nn.functional as F_
    from boxes.deltamem import DH
    H_ADD, H_DEL = mem.h_add, mem.h_del                                     # §178: the memory's own head counts
    with torch.autocast("cuda", enabled=False):
        b, D = x.shape; q = mem.qkv(mem.ln(x.float()))[..., :D].view(b, H_ADD + H_DEL, DH)
        from boxes.deltamem import add_read, state_z                      # §185: the additive read as the run's own (den / rms); delta slice explicit
        oa = torch.exp(mem.s_add) * add_read(mem, F_.elu(q[:, :H_ADD]) + 1, S[:, :H_ADD].float(), state_z(mem, S))
        od = torch.exp(mem.s_del) * torch.einsum("bhvk,bhk->bhv", S[:, H_ADD:H_ADD + H_DEL].float(), F_.normalize(q[:, H_ADD:], dim=-1))
        return torch.cat([oa, od], 1).flatten(1)


@torch.no_grad()
def dec_reads(m, items, T, dev, ac, bs):
    """note 170-2: after think pass t = 1..T, the decoder's memory read r_t at its " =" position (the read entering block mem.layer; the residual there does
    not depend on the memory) -> (T, N, 768)."""
    g = m.g; out = []
    for i in range(0, len(items), bs):
        ch = items[i:i + bs]; seqs = [[EOT] + ids(it["syms"]) + [TID[" ="]] for it in ch]; ids_, _ = pad(seqs); x = torch.tensor(ids_, device=dev)
        pos = torch.tensor([len(q) - 1 for q in seqs], device=dev); xt, msk = m.think_inputs(ch, dev); rs = []
        with ac():
            h = g.embed(x) + m.DM.wpe_slice(g, x.shape[1])[None]
            for j in range(m.mem.layer):
                h = m.DM._block(g, j, h, h.shape[-1] // g.H)
            h6 = h[torch.arange(len(ch), device=dev), pos]; S = m.mem.zero_state(len(ch), dev)
            for _ in range(T):
                S = m.write(S, xt, msk); rs.append(_mem_read(m.mem, h6, S))
        out.append(torch.stack(rs).float().cpu().numpy())
    return np.concatenate(out, 1)


def logreg_acc(Xf, yf, Xs, ys, dev, wd=1e-3, iters=200, n_cls=None):
    """multinomial logistic probe (standardised features, L2 wd, LBFGS) fit on (Xf, yf) -> accuracy on (Xs, ys)."""
    import torch.nn.functional as F_
    mu, sd = Xf.mean(0), Xf.std(0) + 1e-6
    Xf_ = torch.tensor((Xf - mu) / sd, device=dev, dtype=torch.float32); Xs_ = torch.tensor((Xs - mu) / sd, device=dev, dtype=torch.float32)
    yf_ = torch.tensor(yf, device=dev, dtype=torch.long); ys_ = torch.tensor(ys, device=dev, dtype=torch.long)
    with torch.enable_grad(), torch.autocast("cuda", enabled=False):
        nc_ = int(n_cls or P)                                                # 2026-10-11: n_cls for probes with more than P classes (prosqa168s2's concept names)
        W = torch.zeros(Xf.shape[1], nc_, device=dev, requires_grad=True); b = torch.zeros(nc_, device=dev, requires_grad=True)
        opt = torch.optim.LBFGS([W, b], lr=1.0, max_iter=iters, line_search_fn="strong_wolfe")

        def clos():
            opt.zero_grad(); l_ = F_.cross_entropy(Xf_ @ W + b, yf_) + wd * (W ** 2).sum(); l_.backward(); return l_
        opt.step(clos)
    return float(((Xs_ @ W + b).argmax(1) == ys_).float().mean())


def step_recover(m, excl, TE, T, dev, ac, bs, n_fit=int(os.environ.get("NESTED170_PROBE_N_FIT", 4000)), n_test=1000):   # env: gate-size probe fits only
    """note 170-2 (descriptive): per pass t, a multinomial logistic probe from r_t to v_t (the t-th leftmost reduction's value, Z11); fit on n_fit
    training-distribution items (seed 17021), tested on n_test test items at n <= 8 (seed 17022); items with fewer than t reductions are dropped at t."""
    tr = train_items(np.random.default_rng(17021), n_fit, 8, excl); pool = [it for it in TE if it["n"] <= 8]
    te = [pool[i] for i in np.random.default_rng(17022).permutation(len(pool))[:n_test]]
    Rf, Rs = dec_reads(m, tr, T, dev, ac, bs), dec_reads(m, te, T, dev, ac, bs); vf = [reductions(it["root"]) for it in tr]; vs = [reductions(it["root"]) for it in te]
    acc, nn, maj = {}, {}, {}
    for t in range(1, T + 1):
        fi = [i for i, v in enumerate(vf) if len(v) >= t]; si = [i for i, v in enumerate(vs) if len(v) >= t]
        if len(fi) < 100 or len(si) < 20:
            continue
        yf = np.array([vf[i][t - 1] for i in fi]); ys = np.array([vs[i][t - 1] for i in si])
        acc[str(t)] = logreg_acc(Rf[t - 1, fi], yf, Rs[t - 1, si], ys, dev); nn[str(t)] = {"fit": len(fi), "test": len(si)}
        maj[str(t)] = float((ys == np.bincount(yf, minlength=P).argmax()).mean())
    return acc, {"n": nn, "majority_baseline": maj, "probe": "multinomial logistic on standardised r_t (768-d), L2 1e-3, LBFGS 200", "seeds": [17021, 17022]}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--arm", required=True, choices=["direct", "inject", "textcot", "readslots"]); ap.add_argument("--n_slots", type=int, default=8); ap.add_argument("--think_k", type=int, default=0)
    ap.add_argument("--steps", type=int, default=48000); ap.add_argument("--bs", type=int, default=64); ap.add_argument("--lr", type=float, default=1e-4); ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--n_max_train", type=int, default=8); ap.add_argument("--micro", type=int, default=1); ap.add_argument("--ckpt_passes", action="store_true")
    ap.add_argument("--mem_write", default="top", choices=["top"]); ap.add_argument("--write_mix_start", type=int, default=2000); ap.add_argument("--write_mix_end", type=int, default=6000)
    ap.add_argument("--anneal", default="", help="note 196-1 BUDGET-ANNEAL: 'nmax:K:until,...' stages (n_max_train, think_k, last step); each continues the previous "
                    "stage's weights / optimiser; the last stage must equal --n_max_train / --think_k / --steps ('' = off)")
    ap.add_argument("--probe_loss_every", type=int, default=0, help="note 196-1: every N steps, the mean answer / aux CE on 256 FIXED full-task items (n <= --n_max_train, "
                    "K = --think_k; own rng seed + 19700; no_grad, eval mode; logged as probe_loss / probe_aux; 0 = off)")
    ap.add_argument("--mem_layer", type=int, default=6, help="§198 MEM-HIGH: the block the memory branch enters (pretrained trunk; default 6 = §170); --cache_lower caches 0..mem_layer-1")
    ap.add_argument("--cache_lower", action="store_true", help="training only: blocks 0..mem.layer-1 on the (identical) think input once per batch, shared by the K "
                    "passes (exact in exact arithmetic; gate_cache_lower_n170). Held: never compare a cached cell with an uncached comparator (Theory)")
    ap.add_argument("--anneal_gate", default="", help="note 196-1 entry-gated --anneal: 'thr:need:max_steps[:bin]'; --anneal stages 'nmax:K:G' (gated) and a final "
                    "'nmax:K:final_len'; --steps must equal the cap (#gated x max_steps + final_len); LR = the cosine over that cap; '' = fixed-step --anneal")
    ap.add_argument("--csr", default="", help="§199 CSR (Theory 199-A): 'w,lam_min,lam_post,tau,start' - the contraction-schedule regulariser on the aux path's per-pass read R_t, active from step start ('' = off)")
    ap.add_argument("--keep_ckpt_steps", default="", help="§199: comma steps at which a model-only copy ckpt_model_<step>.pt is kept (for the local path_indep probe)")
    ap.add_argument("--iit", default="", help="IIT-SERIAL (boxes/iit_serial.py): 'w_I,w_S,B_I' - the gamma-weighted interchange (IIT) + same-state (SIIT) terms, "
                    "one separate graph after the main backward, only while gamma(step) > 0 ('' = off)")
    ap.add_argument("--iit_tau", type=int, default=1, help="IIT-SERIAL: the swap pass tau"); ap.add_argument("--iit_nmax", type=int, default=0, help="IIT-SERIAL: pairs only from items n <= nmax (0 = all)")
    ap.add_argument("--grokfast", default="", choices=["", "ema"], help="§196: Grokfast EMA gradient filter (grokfast_ema) after backward, before the clip; '' = off")
    ap.add_argument("--gf_alpha", type=float, default=0.98); ap.add_argument("--gf_lamb", type=float, default=2.0)
    ap.add_argument("--ckpt_every", type=int, default=2000); ap.add_argument("--resume", default=None); ap.add_argument("--log_every", type=int, default=100)
    ap.add_argument("--cot_eval_bs", type=int, default=64, help="TEXT-COT generation batch (KV cache; b223 OOMed at 250 on n = 16 chains)"); ap.add_argument("--eval_only", action="store_true", help="evaluate <out>/model.pt (no training; writes args_eval.json; model.pt / args.json / log untouched)"); ap.add_argument("--eval_bs", type=int, default=250); ap.add_argument("--per_n", type=int, default=1000); ap.add_argument("--serial_pool", type=int, default=2200); ap.add_argument("--auto_micro", action="store_true")
    ap.add_argument("--mem_budget", type=float, default=21.0); ap.add_argument("--mem_check", action="store_true"); ap.add_argument("--time_steps", type=int, default=0, help="cost check: train this many steps, report s/step, exit")
    ap.add_argument("--eval_at", type=int, default=0, help="also evaluate acc_by_n at this step -> eval_<k>k.json"); ap.add_argument("--aux_step", type=float, default=0.0, help="§175: lambda of the read-only step decoder CE (0 = off: the §170 path)"); ap.add_argument("--aux_fade", default="36000,48000", help="§175: lambda constant to the first step, then linear to 0 at the second"); ap.add_argument("--kmatch_impl", default="masked", choices=["masked", "bucketed"], help="§177 (f): note 177-5's masked single batch, or the per-K groups"); ap.add_argument("--add_norm", default="", choices=["", "den", "rms"], help="§185 ADD-NORM: the additive reads normalised by phi(q)^T z (den) or per-head RMS (rms); '' = off"); ap.add_argument("--aux_nopass", action="store_true", help="§187 AUX-NOPASS: the aux prompt [EOT, ' Step', ' :'] (no pass token) in training and every aux eval"); ap.add_argument("--aux_reweight", action="store_true", help="§184: the aux CE of pass t <= n weighted by AUX_W[t-1] (equal expected weight per pass position)"); ap.add_argument("--aux_hold", action="store_true", help="§182 HOLD: aux target e_{n+1} on passes n < t <= K (with --k_window and --aux_step)"); ap.add_argument("--kprimes", default="", help="§182: the K' set for s170.acc_by_n_kprime ('' = {0, 1, K/2, K, 2K})"); ap.add_argument("--path_indep", action="store_true", help="§182: s182.path_indep (K' = 16 from M_0 = 0 vs another item's 8-pass memory)"); ap.add_argument("--excl_min_n", type=int, default=1, help="note 178-3 (s178b): exclude test items from training only for n >= this (1 = §170's protocol)"); ap.add_argument("--scratch", default="", help="§178: 'L,D,H' -> a RANDOM-INIT GPT-2 trunk (no pretrained weights), memory after block L // 2 with D / 128 + D / 128 heads"); ap.add_argument("--warmup", type=int, default=100, help="LR warm-up steps (§178: 1000)"); ap.add_argument("--k_window", default="", help="§177 (f): 'lo,hi' -> each n-bucketed micro-batch runs K = n + U{lo..hi} think passes (inject)"); ap.add_argument("--fast_add", action="store_true", help="deltamem.FAST_ADD: the additive heads' pass writes as one sum (Audit 2026-10-09; scratch/gate_fastadd.py)"); ap.add_argument("--sched_scale", type=float, default=1.0, help="smokes only"); ap.add_argument("--fp32", action="store_true"); ap.add_argument("--device", default="cuda:0"); ap.add_argument("--out", required=True)
    a = ap.parse_args(); a.task = "nested"
    assert not (a.aux_reweight and a.aux_hold), "§188: --aux_reweight with --aux_hold is not defined (reweight applies to the real steps only)"
    import boxes.deltamem as DM_; DM_.FAST_ADD = bool(a.fast_add); os.makedirs(a.out, exist_ok=True); dev = a.device; sc = a.sched_scale; K = a.think_k if a.arm in ("inject", "readslots") else 0
    if a.arm not in ("inject", "readslots"):
        a.mem_write = a.write_mix_start = a.write_mix_end = None; a.think_k = 0
    from boxes import s5
    from boxes import core as bc
    from boxes.fsq120 import make_opt, lr_at, driver_version, env_info
    torch.manual_seed(a.seed); rng = np.random.default_rng(a.seed)
    amp = None if (a.fp32 or not dev.startswith("cuda") or torch.cuda.get_device_capability(dev)[0] < 8) else torch.bfloat16
    ac = lambda: torch.autocast("cuda", dtype=amp, enabled=amp is not None)  # noqa: E731
    TE = test_set(a.per_n); EXCL = {tuple(it["syms"]) for it in TE if it["n"] >= a.excl_min_n}; g = make_trunk(vars(a), dev); ML, HA, HD = mem_geometry(vars(a))   # note 178-3: excl_min_n
    r_sp = np.random.default_rng(17300); SPOOL = []                         # note 170-1: the dedicated n = 8 SERIAL pool (excluded from training)
    for _ in range(a.serial_pool):
        r__, t__ = generate(r_sp, 8); s__ = render(r__); SPOOL.append({"n": 8, "syms": s__, "t": t__, "depth": depth(s__), "root": r__})
    EXCL |= {tuple(it["syms"]) for it in SPOOL}
    r_ex = np.random.default_rng(17899)                                     # note 178-3: the share of training draws surviving the exclusion, per n (own stream)
    a.excl_survive_by_n = {str(n_): round(float(np.mean([tuple(render(generate(r_ex, n_)[0])) not in EXCL for _ in range(2000)])), 4) for n_ in range(1, a.n_max_train + 1)}
    if a.arm == "readslots":                                                # §198 (c)
        assert not (a.cache_lower or a.k_window or a.anneal or a.grokfast), "--arm readslots: no --cache_lower / --k_window / --anneal / --grokfast"
    m = ((ReadSlotsN(g, ML, a.mem_write, HA, HD, a.add_norm or None, a.n_slots) if a.arm == "readslots" else InjectN(g, ML, a.mem_write, HA, HD, a.add_norm or None)).to(dev)
         if a.arm in ("inject", "readslots") else None)
    if m is not None:
        m.nopass = bool(a.aux_nopass)                                       # §187

    CSR = [float(v_) for v_ in a.csr.split(",")] if a.csr else None       # §199: [w, lam_min, lam_post, tau, start]
    if CSR:
        assert a.arm == "inject" and not (a.cache_lower or a.k_window or a.anneal or a.ckpt_passes), "--csr: the RMS recipe's uncached inject aux path"
    cur_step = [0]; csr_acc = {"pre": [], "pre_add": [], "pre_del": [], "post": [], "loss": []}
    KEEP_CK = {int(v_) for v_ in a.keep_ckpt_steps.split(",")} if a.keep_ckpt_steps else set()

    def loss_items(items, Kb=None):
        if a.arm == "direct":
            seqs = [[EOT] + ids(it["syms"]) + [TID[" ="]] for it in items]; ids_, _ = pad(seqs); x = torch.tensor(ids_, device=dev)
            with ac():
                h, _ = g(g.embed(x), None)
            pos = torch.tensor([len(q) - 1 for q in seqs], device=dev); lg = g.logits(h[torch.arange(len(seqs), device=dev), pos]).float()
            return Fn.cross_entropy(lg, torch.tensor(NUM_IDS[[it["t"] for it in items]], device=dev))
        if a.arm == "textcot":
            seqs, lab = [], []
            for it in items:
                pre = [EOT] + ids(it["syms"]) + [TID[" ="]]; tgt = cot_ids(it["root"]); seqs.append(pre + tgt); lab.append([-100] * len(pre) + tgt)
            ids_, _ = pad(seqs); lb, _ = pad(lab, -100); x = torch.tensor(ids_, device=dev); y = torch.tensor(lb, device=dev)
            with ac():
                h, _ = g(g.embed(x), None)
            lg = g.logits(h[:, :-1]).float(); return Fn.cross_entropy(lg.reshape(-1, lg.shape[-1]), y[:, 1:].reshape(-1), ignore_index=-100)
        x, msk = m.think_inputs(items, dev)
        if not lam_now[0]:                                                  # §170 (and §175 at lambda 0): unchanged
            with ac():
                S = m.think(m.mem.zero_state(len(items), dev), x, msk, K if Kb is None else Kb, ckpt=a.ckpt_passes, h_low=m.lower(x) if a.cache_lower else None); lg = m.dec_logits(S, items, dev)
            return Fn.cross_entropy(lg, torch.tensor(NUM_IDS[[it["t"] for it in items]], device=dev))
        from torch.utils.checkpoint import checkpoint
        per = [[] for _ in items]                                           # §175: the aux CE (token mean) of each item's passes 1..#steps
        csr_on = bool(CSR) and cur_step[0] >= CSR[4] and torch.is_grad_enabled()
        with ac():
            S = m.mem.zero_state(len(items), dev); hl = m.lower(x) if a.cache_lower else None
            if csr_on:                                                      # §199: h6 = blocks 0..layer-1 once, no gradient into them from the CSR
                with torch.no_grad():
                    h6c = DM_.gpt_lower(g, g.embed(x), m.mem.layer)
                ra_, rd_ = read_parts(m.mem, h6c, S); R_ = [ra_ + rd_]; RA_ = [ra_.detach()]; RD_ = [rd_.detach()]
            for t in range(1, K + 1):
                S = checkpoint(m.write, S, x, msk, hl, use_reentrant=False) if (a.ckpt_passes and torch.is_grad_enabled()) else m.write(S, x, msk, hl)
                if csr_on:
                    ra_, rd_ = read_parts(m.mem, h6c, S); R_.append(ra_ + rd_); RA_.append(ra_.detach()); RD_.append(rd_.detach())
                idx = [i for i, it in enumerate(items) if len(aux_of(it)) >= t]
                if idx:
                    lg_a, y_a = m.aux_logits(S[idx], [items[i] for i in idx], t, dev)
                    ce = Fn.cross_entropy(lg_a.transpose(1, 2), y_a, ignore_index=-100, reduction="none").sum(1) / (y_a != -100).sum(1)
                    for r_, i in enumerate(idx):
                        per[i].append(ce[r_] * AUX_W[t - 1] if a.aux_reweight else ce[r_])   # §184: w_t inside §175's per-item mean
            lg = m.dec_logits(S, items, dev)
        la = Fn.cross_entropy(lg, torch.tensor(NUM_IDS[[it["t"] for it in items]], device=dev))
        aux = torch.stack([torch.stack(p_).mean() for p_ in per if p_]).mean(); aux_hist.append((float(la), float(aux)))
        if csr_on:                                                          # §199: + w * csr; log stats (no rng drawn)
            ns_ = [it["n"] for it in items]; lam_ = csr_lams(R_, msk); csr_ = csr_terms(lam_, ns_, K, CSR[1], CSR[2], CSR[3])
            with torch.no_grad():
                pr_, po_ = csr_item_stats(lam_.detach(), ns_, K); pa_, _ = csr_item_stats(csr_lams(RA_, msk), ns_, K); pd_, _ = csr_item_stats(csr_lams(RD_, msk), ns_, K)
            csr_acc["pre"] += pr_; csr_acc["post"] += po_; csr_acc["pre_add"] += pa_; csr_acc["pre_del"] += pd_; csr_acc["loss"].append(float(csr_))
            return la + lam_now[0] * aux + CSR[0] * csr_
        return la + lam_now[0] * aux

    def mem_check(micro):
        cur_step[0] = 10 ** 9 if CSR else cur_step[0]                       # §199: the memory check includes the CSR path (largest shape)
        torch.cuda.reset_peak_memory_stats(dev); r_ = np.random.default_rng(0); its = [it for it in train_items(r_, 4 * a.bs, a.n_max_train, set()) if True]
        its = sorted(its, key=lambda it: -len(it["syms"]))[:a.bs // micro]
        if KW:                                                              # §177 (f) (Audit): the path that trains - the masked kmatch loss, every item at K_max
            if lam_now[0]:                                                  # §182: the aux on the masked kmatch path (every item at K_max)
                la_, ax_, hx_, _ = kmatch_aux_loss(m, its, [a.n_max_train + KW[1]] * len(its), dev, ac, a.aux_hold, a.aux_reweight, cache=a.cache_lower); l_ = la_ + lam_now[0] * (ax_ + hx_)
            else:
                l_, _ = kmatch_loss(m, its, [a.n_max_train + KW[1]] * len(its), dev, ac, masked=a.kmatch_impl == "masked", cache=a.cache_lower)
        else:
            l_ = loss_items(its)
        l_.backward(); (m or g).zero_grad(set_to_none=True)
        evaluate_n(sorted([it for it in TE if it["n"] == 16], key=lambda it: -len(it["syms"]))[:a.eval_bs], max(2 * K, 20 if KW else 0))   # n = 16 at K' = 2K ((f): >= n + 4)
        return torch.cuda.max_memory_allocated(dev) / 2 ** 30

    @torch.no_grad()
    def inject_answers(items, Kp, skip=(), override=None):
        out = []
        for i in range(0, len(items), a.eval_bs):
            ch = items[i:i + a.eval_bs]; x, msk = m.think_inputs(ch, dev)
            with ac():
                S = m.mem.zero_state(len(ch), dev)
                for t in range(1, Kp + 1):
                    if t not in skip:
                        S = m.write(S, x, msk)
                    if override is not None and override[0] == t:
                        S = torch.tensor(override[1][i:i + a.eval_bs], device=dev, dtype=S.dtype)
                lg = m.dec_logits(S, ch, dev)
            out.append(lg[:, NUM_IDS].argmax(-1).cpu().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def inject_states(items, t):
        out = []
        for i in range(0, len(items), a.eval_bs):
            ch = items[i:i + a.eval_bs]; x, msk = m.think_inputs(ch, dev)
            with ac():
                S = m.mem.zero_state(len(ch), dev)
                for _ in range(t):
                    S = m.write(S, x, msk)
            out.append(S.float().cpu().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def direct_answers(items):
        out = []
        for i in range(0, len(items), a.eval_bs):
            ch = items[i:i + a.eval_bs]; seqs = [[EOT] + ids(it["syms"]) + [TID[" ="]] for it in ch]; ids_, _ = pad(seqs); x = torch.tensor(ids_, device=dev)
            with ac():
                h, _ = g(g.embed(x), None)
            pos = torch.tensor([len(q) - 1 for q in seqs], device=dev); out.append(g.logits(h[torch.arange(len(ch), device=dev), pos]).float()[:, NUM_IDS].argmax(-1).cpu().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def cot_answers(items):
        """greedy CoT, budget = the true CoT length + 50, batched by equal prefix length (KV cache); the answer = the text after the last " =" before EOT
        when it is a single number; returns (answers (-1 = wrong form), generated token counts)."""
        ans = np.full(len(items), -1); ntok = np.zeros(len(items), np.int64); by_len = {}
        for i, it in enumerate(items):
            by_len.setdefault(len(it["syms"]), []).append(i)
        for L, idx in by_len.items():
            for s in range(0, len(idx), a.cot_eval_bs):
                ii = idx[s:s + a.cot_eval_bs]; x = torch.tensor([[EOT] + ids(items[j]["syms"]) + [TID[" ="]] for j in ii], device=dev)
                budget = max(len(cot_ids(items[j]["root"])) for j in ii) + 50
                with ac():
                    h, past = g(g.embed(x), None)
                gen = []; done = torch.zeros(len(ii), dtype=torch.bool, device=dev)
                for _ in range(budget):
                    nt = g.logits(h[:, -1]).float().argmax(-1); gen.append(nt); done |= nt == EOT
                    if bool(done.all()):
                        break
                    with ac():
                        h, past = g(g.embed(nt[:, None]), past)
                G = torch.stack(gen, 1).cpu().numpy(); del h, past, gen
                if dev.startswith("cuda"):
                    torch.cuda.empty_cache()
                for r, j in enumerate(ii):
                    row = list(G[r]); e = row.index(EOT) if EOT in row else len(row); body = row[:e]; ntok[j] = e + (1 if EOT in row else 0)
                    if EOT not in row:
                        continue
                    last = max([k for k, tk in enumerate(body) if tk == TID[" ="]], default=-1); tail = body[last + 1:]
                    if len(tail) == 1 and tail[0] in NUM_IDS:
                        ans[j] = int(np.where(NUM_IDS == tail[0])[0][0])
        return ans, ntok

    f0_, f1_ = [float(x_) for x_ in a.aux_fade.split(",")]; lam_now = [0.0]; aux_hist = []
    IITW = None; iit_hist = []; iit_calls = [0]
    if a.iit:                                                               # IIT-SERIAL: own rng (seed + 20500), never the training stream
        import boxes.iit_serial as IIT
        IITW = [float(v_) for v_ in a.iit.split(",")]; assert len(IITW) == 3 and a.arm == "inject" and not a.k_window, "--iit: 'w_I,w_S,B_I', inject arm, no --k_window"
        iit_rng = np.random.default_rng(a.seed + 20500)
    KW = [int(x_) for x_ in a.k_window.split(",")] if a.k_window else None; rng_kw = np.random.default_rng(17900 + a.seed); kcount = {}; loss_log = []
    if KW:
        assert a.arm == "inject" and K >= a.n_max_train + KW[1], "§177 (f): --think_k must cover the largest bucket's K (memcheck / calibration)"

    GATE, GST = None, []
    if a.anneal_gate:                                                       # note 196-1 entry-gated mode: [(n_max_train, K), ...] + the gate
        GST = [tuple(st_.split(":")) for st_ in a.anneal.split(",")]; gp_ = a.anneal_gate.split(":")
        assert len(GST) >= 2 and all(st_[2] == "G" for st_ in GST[:-1]) and GST[-1][2] != "G", "--anneal_gate: stages 'n:K:G', ..., 'n:K:final_len'"
        GATE = AnnealGate(len(GST), float(gp_[0]), int(gp_[1]), int(gp_[2]), int(GST[-1][2]), int(gp_[3]) if len(gp_) > 3 else 1000)
        GST = [(int(st_[0]), int(st_[1])) for st_ in GST]
        assert a.arm == "inject" and not a.k_window and GST[-1] == (a.n_max_train, a.think_k), "--anneal_gate: inject, no --k_window, last stage = (--n_max_train, --think_k)"
        assert a.steps == (len(GST) - 1) * GATE.max_steps + GATE.final_len, "--anneal_gate: --steps must be the cap (#gated x max_steps + final_len)"
        assert GATE.max_steps % GATE.bin == 0
    ANNEAL = [tuple(int(v_) for v_ in st_.split(":")) for st_ in a.anneal.split(",")] if (a.anneal and not GATE) else []   # note 196-1: [(n_max_train, K, until), ...]
    if ANNEAL:
        assert a.arm == "inject" and not KW, "--anneal: inject without --k_window"
        assert all(u0 < u1 for (_, _, u0), (_, _, u1) in zip(ANNEAL, ANNEAL[1:])) and ANNEAL[-1] == (a.n_max_train, a.think_k, a.steps), \
            "--anneal: increasing stage ends; the last stage = (--n_max_train, --think_k, --steps) (memcheck / calibration / eval use it)"
    an_cur = [None]; an_reason = [None]
    if GATE and a.aux_step:
        assert float(a.aux_fade.split(",")[1]) >= a.steps, "--anneal_gate: --aux_fade must reach the cap (the aux on to the end)"

    def lam_at(step):
        """§175: lambda = aux_step to f0, then linear to 0 at f1 (sched_scale-scaled)."""
        if not a.aux_step:
            return 0.0
        return a.aux_step if step <= f0_ * sc else a.aux_step * max(0.0, (f1_ * sc - step) / max(1.0, (f1_ - f0_) * sc))

    @torch.no_grad()
    def aux_hold_eval(items, Kp):
        """§182 HOLD: after each pass n < t <= Kp, greedy exact match of e_{n+1} + EOT (step n's target) -> ({t - n: acc}, overall, {t - n: count})."""
        ex = {}
        for i in range(0, len(items), a.eval_bs):
            ch = items[i:i + a.eval_bs]; x, msk = m.think_inputs(ch, dev)
            with ac():
                S = m.mem.zero_state(len(ch), dev)
                for t in range(1, Kp + 1):
                    S = m.write(S, x, msk); idx = [j for j, it in enumerate(ch) if len(aux_of(it)) < t]
                    if not idx:
                        continue
                    sub = [ch[j] for j in idx]; tg_ = [ids(aux_of(it)[-1][0]) + [EOT] for it in sub]; gen = m.aux_greedy(S[idx], t, max(len(q) for q in tg_))
                    for r_, it in enumerate(sub):
                        ex.setdefault(t - len(aux_of(it)), []).append(bool(list(gen[r_, :len(tg_[r_])]) == tg_[r_]))
        allv = [v for vs in ex.values() for v in vs]
        return {str(k_): float(np.mean(v)) for k_, v in sorted(ex.items())}, (float(np.mean(allv)) if allv else None), {str(k_): len(v) for k_, v in sorted(ex.items())}

    @torch.no_grad()
    def aux_eval(items, Kp, tmax):
        """§175: after each think pass t <= min(n, tmax): greedy exact match of e_{t+1} + EOT; teacher-forced argmax at the newly reduced value vs the copied tokens."""
        ex, role = {}, {}
        for i in range(0, len(items), a.eval_bs):
            ch = items[i:i + a.eval_bs]; x, msk = m.think_inputs(ch, dev)
            with ac():
                S = m.mem.zero_state(len(ch), dev)
                for t in range(1, Kp + 1):
                    S = m.write(S, x, msk)
                    if t > tmax:
                        continue
                    idx = [j for j, it in enumerate(ch) if len(aux_of(it)) >= t]
                    if not idx:
                        continue
                    sub = [ch[j] for j in idx]; lg_a, y_a = m.aux_logits(S[idx], sub, t, dev); pr = lg_a.argmax(-1).cpu().numpy(); yy = y_a.cpu().numpy()
                    gen = m.aux_greedy(S[idx], t, int((yy != -100).sum(1).max()))
                    for r_, it in enumerate(sub):
                        sy, hi = aux_of(it)[t - 1]; L_ = len(sy); tgt = ids(sy) + [EOT]; ok_ = pr[r_, :L_] == yy[r_, :L_]
                        rr = role.setdefault(t, {"handle": [], "copy": []}); rr["handle"].append(bool(ok_[hi])); rr["copy"].extend(bool(ok_[k_]) for k_ in range(L_) if k_ != hi)
                        ex.setdefault(t, []).append(bool(list(gen[r_, :len(tgt)]) == tgt))
        return ({str(t): float(np.mean(v)) for t, v in sorted(ex.items())},
                {str(t): {k_: (float(np.mean(v)) if v else None) for k_, v in d.items()} for t, d in sorted(role.items())}, {str(t): len(v) for t, v in sorted(ex.items())})

    def s175_fields():
        pool = [it for it in TE if it["n"] <= 8]; te8 = [pool[i] for i in np.random.default_rng(17022).permutation(len(pool))[:1000]]
        pe = [it for it in TE if 9 <= it["n"] <= 12]; te12 = [pe[i] for i in np.random.default_rng(17023).permutation(len(pe))[:1000]]
        acc8, role8, n8 = aux_eval(te8, K, K); acc12, _, n12 = aux_eval(te12, 16, 16)
        sr, sri = (None, "n/a for --arm readslots") if a.arm == "readslots" else step_recover(m, EXCL, TE, K, dev, ac, a.eval_bs)
        out = {"aux_acc_by_pass": acc8, "aux_acc_by_pass_ext": acc12, "aux_acc_by_role": role8, "step_recover": sr, "step_recover_info": sri,
               "n_by_pass": n8, "n_by_pass_ext": n12, "ext_kprime": 16, "items": {"n_le_8": {"n": len(te8), "seed": 17022}, "n_9_12": {"n": len(te12), "seed": 17023}}}
        if a.aux_hold:                                                      # §182 HOLD: the hold passes n < t <= K on the same n <= 8 items
            hb, ha, hn = aux_hold_eval(te8, K); out.update({"aux_acc_hold_by_offset": hb, "aux_acc_hold": ha, "n_hold_by_offset": hn})
        return out

    def kn_answers(items, kfun, skip=()):
        """§177 (f): inject answers with a per-n K' = kfun(n) (items grouped by n, order kept)."""
        out = np.full(len(items), -1)
        for n_ in sorted({it["n"] for it in items}):
            ix = [i for i, it in enumerate(items) if it["n"] == n_]; out[ix] = inject_answers([items[i] for i in ix], kfun(n_), skip=tuple(t for t in skip if t <= kfun(n_)))
        return out

    def evaluate_n(items, Kp=None):
        if a.arm == "direct":
            return direct_answers(items)
        if a.arm == "textcot":
            return cot_answers(items)[0]
        return inject_answers(items, K if Kp is None else Kp)

    lam_now[0] = a.aux_step                                                 # §175: memory-check with the aux on (the largest graph)
    if a.mem_check or (a.auto_micro and dev.startswith("cuda") and not a.resume and not a.eval_only):
        mc = []
        while True:
            try:                                                            # 2026-10-09: an OOM inside the check (a hard memory cap) = over budget -> larger micro
                pk = mem_check(a.micro)
            except torch.OutOfMemoryError:
                pk = float("inf")
            if pk != float("inf"):                                       # + AdamW's two fp32 states per parameter (not allocated by the check; ~1 GiB for GPT-2)
                pk += 2 * sum(p_.numel() * 4 for p_ in (m if m is not None else g).parameters() if p_.requires_grad) / 2 ** 30
            torch.cuda.empty_cache()                                    # no fragmentation carried into the next attempt / training
            if pk == float("inf"):                                       # after the except clause, so the failed graph is released
                (m or g).zero_grad(set_to_none=True); torch.cuda.empty_cache()
            mc.append({"micro": a.micro, "peak_gib": pk}); print("MEM", a.micro, pk, flush=True)
            if pk <= a.mem_budget or a.micro >= a.bs or a.mem_check:
                break
            a.micro *= 2
        if a.arm == "textcot" and dev.startswith("cuda"):                   # Audit 2026-10-09 (b223 OOM): the worst CoT eval batch = the longest n = 16 chain x cot_eval_bs
            worst = max([it for it in TE if it["n"] == 16], key=lambda it: len(cot_ids(it["root"])))
            while True:
                torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats(dev); cot_answers([worst] * a.cot_eval_bs); pk_ = torch.cuda.max_memory_allocated(dev) / 2 ** 30
                mc.append({"cot_eval_bs": a.cot_eval_bs, "peak_gib": pk_, "chain_tokens": len(cot_ids(worst["root"]))}); print("MEM cot", a.cot_eval_bs, pk_, flush=True)
                if pk_ <= a.mem_budget or a.cot_eval_bs <= 4:
                    break
                a.cot_eval_bs //= 2
        json.dump({"checks": mc, "micro": a.micro, "peak_gib": mc[-1]["peak_gib"], "train": "the longest of 4 bs draws at n <= %d" % a.n_max_train, "eval": "n = 16 at K' = 2K"},
                  open(os.path.join(a.out, "mem_check.json"), "w", newline="\n"), indent=1)
        if a.mem_check:
            return
        assert mc[-1]["peak_gib"] <= a.mem_budget
    info = {**vars(a), "train_gpu": torch.cuda.get_device_name(dev) if dev.startswith("cuda") else "cpu", "train_driver": driver_version(), **env_info(), "hostprobe_sps": os.environ.get("HOSTPROBE_SPS"),
            "format": {"direct": "[EOT, expr, ' ='] -> the answer token", "inject": "think [EOT, expr, ' .'] (padded writes masked); decoder [EOT, expr, ' ='] -> answer (read-only)",
                       "textcot": "[EOT, expr, ' ='] then ' e2 = e3 = ... = t' EOT (Feng; loss on all generated tokens)",
                       "readslots": "§198 (c): input [EOT, expr] encoded once (no memory read); K passes of n_slots slot tokens after it (read + top writes); decoder ' =' after the input KV (read-only)"}[a.arm]}
    if a.eval_only:                                                         # Theory 2026-10-09: train_gpu / train_driver are the training run's (args.json); the eval GPU is "gpu"
        a0_ = json.load(open(os.path.join(a.out, "args.json"))); info["eval_gpu"], info["eval_driver"] = info["train_gpu"], info["train_driver"]
        info["train_gpu"], info["train_driver"] = a0_.get("train_gpu"), a0_.get("train_driver")
    if a.aux_step:                                                          # §175 (Audit): state the aux decoder's weight sharing in the run's args
        info["aux_decoder"] = ("the SAME GPT-2 trunk and LM head as the main decoder (shared weights, no new parameters), read-only on M_t via fwd_read: "
                               "[EOT, ' Step', ' t', ' :'] + e_{t+1} + EOT (teacher-forced); no problem text, no write, never fed back; dropped at test")
    json.dump(info, open(os.path.join(a.out, "args_eval.json" if a.eval_only else (("args_resume_%d.json" % int(time.time())) if a.resume else "args.json")), "w", newline="\n"), indent=1)
    params = m if m is not None else g; opt = make_opt(params, a.lr); step0 = 1; n_nonfinite = 0; hist = []; wg_hist = []; wwin = []; wlast = []; gn_hist = []; gadd_hist = []; zmin_hist = []; gn_log = []; gf_ema = {}   # gn_log: every step's pre-clip norm (log only; Theory / Audit 2026-10-13)
    log = open(os.path.join(a.out, "log.jsonl"), "a" if (a.resume or a.eval_only) else "w", newline="\n"); t0 = time.time()
    if a.resume:
        ck = torch.load(a.resume, map_location=dev, weights_only=False); params.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); rng.bit_generator.state = ck["np_rng"]
        step0 = ck["step"] + 1; n_nonfinite = ck["n_nonfinite"]; wg_hist = ck.get("wg_hist", []); gn_hist = list(ck.get("gn_hist", [])); gn_log = list(ck.get("gn_log", [])); t0 = time.time() - ck["elapsed"]
        if KW and "rng_kw" in ck:                                           # older checkpoints lack it: the K stream then restarts (not bitwise)
            rng_kw.bit_generator.state = ck["rng_kw"]; kcount = ck.get("kcount", kcount)
        if GATE and "anneal_gate" in ck:                                    # note 196-1: the gate continues (partial bin, consecutive count, stage)
            GATE.load(ck["anneal_gate"]); an_reason[0] = ck.get("an_reason")
        if a.grokfast:                                                      # §196: the EMA state continues (absent -> re-initialised from the next gradient)
            gf_ema = {k_: v_.to(dev) for k_, v_ in ck.get("gf_ema", {}).items()}
        log.write(json.dumps({"step": ck["step"], "resumed": a.resume}) + "\n"); log.flush()
    elif m is not None and K > 0:                                           # note 147-2: g_add calibration at the think hand-offs
        its = train_items(np.random.default_rng(17001), 64, a.n_max_train, set()); x, msk = m.think_inputs(its, dev); m.mem.norms = []
        with torch.no_grad(), ac():
            m.think(m.mem.zero_state(64, dev), x, msk, min(K, 4))
        nr = m.mem.norms[1:]; m.mem.norms = None; r0 = float(torch.stack([d_ / a_.clamp_min(1e-12) for d_, a_ in nr]).median()) if nr else 1.0
        m.mem.s_add.data.fill_(math.log(max(r0, 1e-12))); json.dump({"g_add_init": r0}, open(os.path.join(a.out, "s170_init.json"), "w", newline="\n"))
    last = a.steps if not a.time_steps else min(a.steps, step0 + a.time_steps - 1); tt0 = time.time()
    if a.eval_only:                                                         # no training: the saved model, the training log's time / non-finite count
        params.load_state_dict(torch.load(os.path.join(a.out, "model.pt"), map_location=dev, weights_only=True)); last = step0 - 1
        lg_ = [json.loads(l_) for l_ in open(os.path.join(a.out, "log.jsonl"))]; n_nonfinite = sum(1 for r_ in lg_ if r_.get("nonfinite"))
        sec_ = [r_["sec"] for r_ in lg_ if "sec" in r_]; t0 = time.time() - (sec_[-1] if sec_ else 0)
        wg_hist = [{"step": r_["step"], "mean": r_["write_grad_norm"], "spike_100x_floor": bool(r_.get("write_grad_spike_100x_floor", False)), "from_log": True}
                   for r_ in lg_ if "write_grad_norm" in r_]                 # 2026-10-10: log records -> the training wg_hist form (the eval reads spike_100x_floor)
    PROBE = train_items(np.random.default_rng(a.seed + 19700), 256, a.n_max_train, EXCL) if (a.probe_loss_every and m is not None) else []   # final shape, drawn once
    PROBE_K = K                                                             # the base (final-stage) K: the loop's anneal stages change K, not this
    if PROBE and not a.eval_only:
        import hashlib
        log.write(json.dumps({"step": step0 - 1, "probe_items": len(PROBE), "probe_n_max": a.n_max_train, "probe_k": PROBE_K,
                              "probe_items_sha": hashlib.sha256(json.dumps([it["syms"] for it in PROBE]).encode()).hexdigest()[:16]}) + "\n"); log.flush()

    def probe_losses():
        """note 196-1: mean answer / aux CE on PROBE at PROBE_K; no_grad, eval mode; draws no rng; recorders paused (training state untouched)."""
        params.eval(); zr_ = getattr(m.mem, "zmin_rec", None); m.mem.zmin_rec = None; gon_ = gf_rec["on"]; gf_rec["on"] = False; la_s, ax_s, n_s = 0.0, 0.0, 0
        try:
            with torch.no_grad():
                for i_ in range(0, len(PROBE), a.eval_bs):
                    ch_ = PROBE[i_:i_ + a.eval_bs]; la_, ax_, _, _ = kmatch_aux_loss(m, ch_, [PROBE_K] * len(ch_), dev, ac)
                    la_s += float(la_) * len(ch_); ax_s += float(ax_) * len(ch_); n_s += len(ch_)
        finally:
            m.mem.zmin_rec = zr_; gf_rec["on"] = gon_
        return la_s / n_s, ax_s / n_s
    gf_named = [(n_, p_) for n_, p_ in params.named_parameters() if p_.requires_grad] if a.grokfast else []; gf_rec = {"on": False, "maxlogit": None}
    if a.grokfast and m is not None:                                        # §196 log field: the answer head's max logit on the step's batch (logging steps only)
        _dl_orig = m.dec_logits

        def _dl_rec(S, items, dev_):
            lg_ = _dl_orig(S, items, dev_)
            if gf_rec["on"]:
                v_ = float(lg_.detach().max()); gf_rec["maxlogit"] = v_ if gf_rec["maxlogit"] is None else max(gf_rec["maxlogit"], v_)
            return lg_
        m.dec_logits = _dl_rec
    for step in range(step0, last + 1):
        cur_step[0] = step
        if CSR:                                                             # §199: this step's batch stats only
            for k_ in csr_acc:
                csr_acc[k_].clear()
        if GATE:                                                            # note 196-1 entry-gated: the gate's stage; stop after the final stage's length
            if GATE.end() is not None and step > GATE.end():
                break
            if GATE.stage != an_cur[0]:
                a.n_max_train, K = GST[GATE.stage]; an_cur[0] = GATE.stage
                log.write(json.dumps({"step": step, "anneal_stage": GATE.stage, "n_max_train": a.n_max_train, "think_k": K, "reason": an_reason[0] or "start",
                                      "s_full": GATE.s_full, "end": GATE.end()}) + "\n"); log.flush()
        if ANNEAL:                                                          # note 196-1: the stage of this step (a resume lands in its own stage)
            st_ = next(i_ for i_, (_, _, u_) in enumerate(ANNEAL) if step <= u_)
            if st_ != an_cur[0]:
                a.n_max_train, K = ANNEAL[st_][0], ANNEAL[st_][1]; an_cur[0] = st_
                log.write(json.dumps({"step": step, "anneal_stage": st_, "n_max_train": a.n_max_train, "think_k": K}) + "\n"); log.flush()
        gf_log = a.grokfast and (step % a.log_every == 0 or step == a.steps); gf_rec["on"] = bool(gf_log); gf_rec["maxlogit"] = None; gf_upd = None
        for gr in opt.param_groups:
            gr["lr"] = lr_at(a.lr, gr, step, a.steps) if a.warmup == 100 else lr_at(a.lr, gr, step, a.steps) / min(1, step / 100) * min(1, step / a.warmup)   # §178: --warmup
        params.train()
        if m is not None:
            m.mem.fade.fill_(min(1.0, step / max(1, int(500 * sc))))
            m.mem.gamma.fill_(0.0 if step <= a.write_mix_start * sc else min(1.0, (step - a.write_mix_start * sc) / max(1.0, (a.write_mix_end - a.write_mix_start) * sc)))
        lam_now[0] = lam_at(step)
        if a.add_norm == "den" and m is not None and step == step0 and step <= 500:   # Audit: arm the phi(q)^T z recorder from the first step
            m.mem.zmin_rec = []
        its = train_items(rng, a.bs, a.n_max_train, EXCL); opt.zero_grad(); tot = 0.0; ch = a.bs // a.micro
        if KW:                                                              # §177 (f): the same items / n marginal as §170, bucketed by n, one K per bucket
            assert not lam_now[0] or a.kmatch_impl == "masked", "§182: the aux rides on the masked kmatch batch"
            kb_ = {}
            for n_ in sorted({it["n"] for it in its}):                     # one K per n-bucket per step, drawn in the same order / stream as first built
                bk = [it for it in its if it["n"] == n_]; Kb = n_ + int(rng_kw.integers(KW[0], KW[1] + 1)); kb_[n_] = Kb
                assert all(it["n"] == n_ for it in bk) and KW[0] <= Kb - n_ <= KW[1]; kcount.setdefault(str(n_), {}); kcount[str(n_)][str(Kb)] = kcount[str(n_)].get(str(Kb), 0) + 1
            kit = [kb_[it["n"]] for it in its]                              # note 177-5: the masked single batch (bucketed = --kmatch_impl bucketed)
            for c_ in range(0, len(its), ch):
                sub, ks = its[c_:c_ + ch], kit[c_:c_ + ch]
                if lam_now[0]:                                              # §182 WINDOW / HOLD
                    wr_ = [] if (step == step0 and c_ == 0) else None              # §188 tripwire: the kept real-step weights of step 1's first chunk
                    la_, ax_, hx_, _ = kmatch_aux_loss(m, sub, ks, dev, ac, a.aux_hold, a.aux_reweight, wr_, cache=a.cache_lower); aux_hist.append((float(la_), float(ax_), float(hx_))); lk = la_ + lam_now[0] * (ax_ + hx_)
                    if wr_ is not None:
                        wm_ = float(np.mean(wr_)) if wr_ else None
                        json.dump({"step": step, "aux_w_mean_kept": wm_, "n_terms": len(wr_), "aux_reweight": bool(a.aux_reweight)}, open(os.path.join(a.out, "s188_tripwire.json"), "w", newline="\n"))
                        assert (wm_ is not None and wm_ != 1.0) if a.aux_reweight else True, "§188 tripwire: --aux_reweight set but the window path's kept aux weights average 1.0"
                else:
                    lk, _ = kmatch_loss(m, sub, ks, dev, ac, masked=a.kmatch_impl == "masked", cache=a.cache_lower)
                (lk * len(sub) / a.bs).backward(); tot += float(lk.item()) * len(sub) / a.bs
        else:
          for k_ in range(a.micro):
            lk = loss_items(its[k_ * ch:(k_ + 1) * ch]); (lk / a.micro).backward(); tot += float(lk.item()) / a.micro
        if IITW is not None and m is not None and float(m.mem.gamma) > 0:   # IIT-SERIAL: its own graph after the main backward (draft §2.4); weight gamma(step)
            from boxes.deltas5 import write_grad_norm as _wgn               # Audit: the main loss's write-grad norm BEFORE the IIT backward (comparable to controls)
            li_pre = _wgn(m); l_iit, li_ = IIT.iit_loss(m, its, dev, ac, K, iit_rng, a.iit_tau, a.iit_nmax, int(IITW[2]), IITW[0], IITW[1]); iit_calls[0] += 1
            if l_iit is not None:
                (float(m.mem.gamma) * l_iit).backward()
            li_["wgn_pre_iit"] = li_pre; li_["peak_gib"] = torch.cuda.max_memory_allocated(dev) / 2 ** 30 if dev.startswith("cuda") else None; iit_hist.append(li_)
        if m is not None:
            from boxes.deltas5 import write_grad_norm
            wwin.append(write_grad_norm(m))
        if a.grokfast:                                                      # §196: backward -> filter -> clip -> AdamW
            gf_g, gf_s = grokfast_ema(gf_named, gf_ema, a.gf_alpha, a.gf_lamb, norms=gf_log)
        gn = torch.nn.utils.clip_grad_norm_(params.parameters(), 1.0); gn_log.append(float(gn))
        if a.aux_reweight or a.add_norm:                                    # §184 / §185: the pre-clip grad norm per step (clip fires above 1.0)
            gn_hist.append(float(gn))
        if a.add_norm == "den" and m is not None and step <= 500:           # Audit: min phi(q)^T z over this step's reads, steps 1..500
            if m.mem.zmin_rec:
                zmin_hist.append((step, min(m.mem.zmin_rec)))
            m.mem.zmin_rec = [] if step < 500 else None
        if a.add_norm and m is not None:                                    # §185: the additive path's grad norm (the additive heads' q / k / v rows + the rms gain)
            gq = m.mem.qkv.weight.grad
            if gq is not None:
                ra = [r for blk in range(3) for r in range(blk * m.mem.D, blk * m.mem.D + m.mem.h_add * m.DM.DH)]; ga = gq[ra].float().pow(2).sum()
                if getattr(m.mem, "add_gain", None) is not None and m.mem.add_gain.grad is not None:
                    ga = ga + m.mem.add_gain.grad.float().pow(2).sum()
                gadd_hist.append((step, float(ga.sqrt())))
        if not (math.isfinite(tot) and bool(torch.isfinite(gn))):
            n_nonfinite += 1; opt.zero_grad(); log.write(json.dumps({"step": step, "nonfinite": 1}) + "\n"); log.flush()
        else:
            gf_pre = [p_.detach().clone() for _, p_ in gf_named] if gf_log else None   # §196 log field: the AdamW update norm (logging steps only)
            opt.step(); hist.append(tot)
        if GATE:                                                            # note 196-1: the gate sees every step's training loss (non-finite: skipped)
            tr_ = GATE.update(step, tot if math.isfinite(tot) else None)
            if tr_ is not None:
                an_reason[0] = tr_[1]; log.write(json.dumps({"step": step, "gate_bin_mean": tr_[2], "next_stage": tr_[0], "reason": tr_[1]}) + "\n"); log.flush()
            if gf_pre is not None:
                gf_upd = float(torch.stack([(p_.detach() - q_).float().pow(2).sum() for (_, p_), q_ in zip(gf_named, gf_pre)]).sum().sqrt()); del gf_pre
        if a.eval_at and step == a.eval_at:                                 # Theory 7caa3a82 (§174's matched budget): acc_by_n at this step, no checkpoint kept
            params.eval(); Ne = np.array([it["n"] for it in TE]); Ce = evaluate_n(TE) == np.array([it["t"] for it in TE])
            e_ = {"step": step, "acc_by_n": {str(n): float(Ce[Ne == n].mean()) for n in range(1, 17)}}
            if a.aux_step and K:
                e_["s175"] = s175_fields(); e_["aux_lambda"] = lam_now[0]
            json.dump(e_, open(os.path.join(a.out, "eval_%dk.json" % (step // 1000)), "w", newline="\n"), indent=1)
        if step % a.log_every == 0 or step == a.steps:
            rec = {"step": step, "loss": float(np.mean(hist)) if hist else None, "sec": round(time.time() - t0)}; hist = []; loss_log.append(rec["loss"])
            if a.aux_step:
                rec.update({"aux_lambda": lam_now[0], "answer_ce": float(np.mean([x_[0] for x_ in aux_hist])) if aux_hist else None,
                            "aux_ce": float(np.mean([x_[1] for x_ in aux_hist])) if aux_hist else None})
                if a.aux_hold:                                              # §182 HOLD: the separate hold term
                    rec["hold_aux_ce"] = float(np.mean([x_[2] for x_ in aux_hist])) if aux_hist else None
                aux_hist.clear()
            if IITW is not None:                                            # IIT-SERIAL in-training fields (iit_ce / siit_ce per record; calls so far)
                hs_ = [h_ for h_ in iit_hist if h_.get("iit_pairs")]
                rec.update({"iit_ce": float(np.mean([h_["iit_ce"] for h_ in hs_])) if hs_ else None, "siit_ce": float(np.mean([h_["siit_ce"] for h_ in hs_])) if hs_ else None,
                            "iit_pairs_mean": float(np.mean([h_["iit_pairs"] for h_ in iit_hist])) if iit_hist else None, "iit_calls": iit_calls[0],
                            "write_grad_norm_pre_iit": float(np.mean([h_["wgn_pre_iit"] for h_ in iit_hist])) if iit_hist else None,
                            "peak_gib_since_start": max([h_["peak_gib"] for h_ in iit_hist if h_.get("peak_gib") is not None], default=None)}); iit_hist.clear()
            if m is not None and wwin:
                md_ = float(np.median(wlast)) if wlast else 0.0; mx_ = float(np.max(wwin)); late = step > a.write_mix_start * sc
                w_rec = {"step": step, "mean": float(np.mean(wwin)), "max": mx_, "median_prev_1k": md_, "spike_100x_floor": bool(late and mx_ > 100 * md_ > 0 and mx_ > 1.0)}
                wlast.extend(wwin); del wlast[:-int(1000 * sc) or None]; wwin = []; wg_hist.append(w_rec)
                rec.update({"gamma": float(m.mem.gamma), "fade": float(m.mem.fade), "write_grad_norm": w_rec["mean"], "write_grad_spike_100x_floor": w_rec["spike_100x_floor"]})
            if ANNEAL or GATE:
                rec.update({"anneal_stage": an_cur[0], "n_max_train": a.n_max_train, "think_k": K})
            if GATE:
                rec["lr"] = opt.param_groups[0]["lr"]
            if CSR and step >= CSR[4]:                                     # §199 fields (this step's batch; micro chunks pooled)
                md_ = lambda v_: float(np.median(v_)) if v_ else None      # noqa: E731
                rec.update({"csr_lam_pre_med": md_(csr_acc["pre"]), "csr_lam_pre_med_add": md_(csr_acc["pre_add"]), "csr_lam_pre_med_del": md_(csr_acc["pre_del"]),
                            "csr_lam_post_med": md_(csr_acc["post"]), "csr_loss": float(np.mean(csr_acc["loss"])) if csr_acc["loss"] else None})
            if gf_log:                                                      # §196: slow share, AdamW update norm, answer max logit, total weight norm
                rec.update({"gf_slow_share": (gf_s / gf_g) if gf_g else None, "gf_update_norm": gf_upd, "gf_ans_max_logit": gf_rec["maxlogit"],
                            "gf_weight_norm": float(torch.stack([p_.detach().float().pow(2).sum() for _, p_ in gf_named]).sum().sqrt())})
            if gn_log:                                                      # pre-clip total grad norm at this step + the clip share of the last 100 steps (log only)
                rec.update({"gn_preclip": gn_log[-1], "clip_frac_100": float(np.mean([v_ > 1.0 for v_ in gn_log[-100:]]))})
            log.write(json.dumps(rec) + "\n"); log.flush(); print(rec, flush=True)
        if PROBE and step % a.probe_loss_every == 0:                       # note 196-1: the fixed full-task probe (descriptive)
            pl_, pa_ = probe_losses(); log.write(json.dumps({"step": step, "probe_loss": pl_, "probe_aux": pa_, **({"anneal_stage": an_cur[0]} if ANNEAL else {})}) + "\n"); log.flush()
        if step in KEEP_CK:                                                 # §199: a model-only copy for the local path_indep probe
            torch.save({"model": params.state_dict(), "step": step}, os.path.join(a.out, "ckpt_model_%d.pt" % step))
        if a.ckpt_every and step % a.ckpt_every == 0 and step < a.steps:
            cp = os.path.join(a.out, "ckpt_last.pt")
            if os.path.exists(cp):
                os.replace(cp, os.path.join(a.out, "ckpt_prev.pt"))
            torch.save({"model": params.state_dict(), "opt": opt.state_dict(), "np_rng": rng.bit_generator.state, "step": step, "n_nonfinite": n_nonfinite, "wg_hist": wg_hist, "gn_hist": gn_hist, "gn_log": gn_log,
                        **({"rng_kw": rng_kw.bit_generator.state, "kcount": kcount} if KW else {}), **({"gf_ema": gf_ema} if a.grokfast else {}),
                        **({"anneal_gate": GATE.state(), "an_reason": an_reason[0]} if GATE else {}),   # 2026-10-13: a WINDOW resume continues the same K draws
                        "elapsed": time.time() - t0}, cp)
    if a.time_steps:                                                        # Audit's cost check
        sps = (time.time() - tt0) / max(1, last - step0 + 1); json.dump({"arm": a.arm, "think_k": K, "steps_timed": last - step0 + 1, "sec_per_step": sps, "est_hours_48k": sps * a.steps / 3600,
                                                                       "gpu": torch.cuda.get_device_name(dev) if dev.startswith("cuda") else "cpu", "micro": a.micro},
                                                                      open(os.path.join(a.out, "timing.json"), "w", newline="\n"), indent=1); print("TIMING", sps, flush=True)
        json.dump(json.load(open(os.path.join(a.out, "timing.json"))), open(os.path.join(a.out, "eval.json"), "w", newline="\n"), indent=1); return   # so the drain fetches it
    train_sec = round(time.time() - t0)
    if not a.eval_only:
        torch.save(params.state_dict(), os.path.join(a.out, "model.pt"))
    opt.zero_grad(set_to_none=True); opt.state.clear()                      # Audit 2026-10-09: free the optimizer state and grads before the eval (b223 OOM)
    if dev.startswith("cuda"):
        torch.cuda.empty_cache()
    params.eval(); t1 = time.time()
    N = np.array([it["n"] for it in TE]); Dp = np.array([it["depth"] for it in TE]); T_ = np.array([it["t"] for it in TE])
    if a.arm == "textcot":
        A_, NT = cot_answers(TE)
    elif KW:                                                                # §177 (f): the main eval at K' = n + 1 per item
        A_ = kn_answers(TE, lambda n_: n_ + 1); NT = None
    else:
        A_ = evaluate_n(TE); NT = None
    C = A_ == T_
    res = {"task": "nested", "eval_only": bool(a.eval_only), "arm": a.arm, "think_k": K, "seed": a.seed, "acc_by_n": {str(n): float(C[N == n].mean()) for n in range(1, 17)},
           "acc_by_depth": {str(d): float(C[Dp == d].mean()) for d in sorted(set(Dp.tolist()))}, "n_by_depth": {str(d): int((Dp == d).sum()) for d in sorted(set(Dp.tolist()))},
           "train_sec": train_sec, "n_nonfinite": n_nonfinite, "micro": a.micro, "eval_dtype": str(amp), "gpu": torch.cuda.get_device_name(dev) if dev.startswith("cuda") else "cpu",
           "train_gpu": info["train_gpu"], "train_driver": info["train_driver"], "per_n": a.per_n}
    if NT is not None:
        res["cot_tokens_by_n"] = {str(n): float(NT[N == n].mean()) for n in range(1, 17)}
    mt = lambda: bc.Meter(g)  # noqa: E731
    cb = {}
    for n in range(1, 17):
        L_ = float(np.mean([len(it["syms"]) for it in TE if it["n"] == n])) + 2; M_ = mt()
        if a.arm == "direct":
            M_.step(int(round(L_)), 0, 1)
        elif a.arm == "inject":
            for _ in range(n + 1 if KW else K):                             # §177 (f): K' = n + 1 per item
                M_.step(int(round(L_)), 0, 0)
            M_.step(int(round(L_)), 0, 1)
        elif a.arm == "readslots":                                          # §198 (c): input [EOT, expr] once; K passes of M slots after it; ' =' after it
            Li_ = int(round(L_)) - 1; M_.step(Li_, 0, 0)
            for _ in range(K):
                M_.step(a.n_slots, Li_, 0)
            M_.step(1, Li_, 1)
        else:
            M_.step(int(round(L_)), 0, 1)
            for j in range(int(round(res["cot_tokens_by_n"][str(n)])) - 1):
                M_.step(1, int(round(L_)) + j, 1)
        cb[str(n)] = {"flops_trunk": M_.flops, "sequential_passes": M_.passes}
    res["compute_by_n"] = cb; res["compute_note"] = "boxes.core.Meter per item at the mean length of each n (trunk; the DeltaMem branch adds < 5% at these lengths)"
    if a.arm == "readslots":                                                # §198 (c) eval fields
        res["readslots"] = {"L_mean": float(np.mean([len(it["syms"]) + 1 for it in TE])), "L_mean_by_n": {str(n): float(np.mean([len(it["syms"]) + 1 for it in TE if it["n"] == n])) for n in range(1, 17)},
                            "n_slots": a.n_slots, "def": "L = encoded input tokens [EOT, expr]; FLOPs per item in compute_by_n (Meter: encode once, K slot passes of n_slots after it, ' =')"}
    if a.arm in ("inject", "readslots"):
        s = {"acc_by_n_kprime": {}, "skip_pass": {}, "serial": {}, "write_grad_norm": wg_hist, "write_grad_spikes_floor": [x_ for x_ in wg_hist if x_["spike_100x_floor"]], "n_nonfinite": n_nonfinite}
        for kp in sorted({int(x_) for x_ in a.kprimes.split(",")} | {K} if a.kprimes else {0, 1, K // 2, K, 2 * K}):   # §182: --kprimes
            Ak = A_ if kp == K else inject_answers(TE, kp); s["acc_by_n_kprime"][str(kp)] = {str(n): float((Ak == T_)[N == n].mean()) for n in range(1, 17)}
        if a.kprimes:                                                       # note 182-3 (§182 cells): n-relative K' = n and n + 2 (per-n readout, as (f)'s kn_answers)
            for kk_, f_ in (("n", lambda n_: n_), ("n+2", lambda n_: n_ + 2)):
                Ak = kn_answers(TE, f_); s["acc_by_n_kprime"][kk_] = {str(n): float((Ak == T_)[N == n].mean()) for n in range(1, 17)}
        for t in sorted({t for t in (1, K // 4, K // 2, 3 * K // 4, K) if t >= 1}):
            Ak = inject_answers(TE, K, skip=(t,)); s["skip_pass"][str(t)] = {str(n): float((Ak == T_)[N == n].mean()) for n in range(1, 17)}
        rec_, don_, hyb_ = serial_items(SPOOL, np.random.default_rng(17200)); s["n_serial_items"] = len(rec_); s["serial_pool"] = {"n": len(SPOOL), "seed": 17300}
        if rec_:
            tr = np.array([value(it["root"]) for it in rec_]); td = np.array([value(it["root"]) for it in don_]); th = np.array(hyb_)
            for t in sorted({t for t in (1, 2, K // 4, K // 2, 3 * K // 4) if 1 <= t < K}):
                Sd = inject_states(don_, t); got = inject_answers(rec_, K, override=(t, Sd))
                s["serial"][str(t)] = {"hybrid": float((got == th).mean()), "donor": float((got == td).mean()), "recipient": float((got == tr).mean())}
            perm = np.random.default_rng(17201).permutation(len(rec_)); tnull = sorted(s["serial"])[0] if s["serial"] else None
            if tnull is not None:
                Sn = inject_states([rec_[i] for i in perm], int(tnull)); gotn = inject_answers(rec_, K, override=(int(tnull), Sn)); s["serial_null"] = {"t": int(tnull), "hybrid": float((gotn == th).mean())}
        if K and a.arm == "readslots":
            s["step_recover"], s["step_recover_info"] = None, "n/a for --arm readslots (dec_reads assumes InjectN's [EOT, expr, ' ='] read position)"
        elif K:                                                             # note 170-2 (descriptive)
            s["step_recover"], s["step_recover_info"] = step_recover(m, EXCL, TE, K, dev, ac, a.eval_bs)
        res["s170"] = s
        if KW:                                                              # §177 (f) fields
            kfs = {"0": lambda n_: 0, "1": lambda n_: 1, "n": lambda n_: n_, "n+1": lambda n_: n_ + 1, "n+2": lambda n_: n_ + 2, "n+4": lambda n_: n_ + 4}
            s7 = {"acc_by_n_kprime": {}, "skip_pass": {}, "kmatch_counts": kcount, "k_window": a.k_window, "rule_kprime": "n+1"}
            for kk_, f_ in kfs.items():
                Ak = A_ if kk_ == "n+1" else kn_answers(TE, f_); s7["acc_by_n_kprime"][kk_] = {str(n): float((Ak == T_)[N == n].mean()) for n in range(1, 17)}
            for t in range(1, a.n_max_train + 2):                           # skip pass t at K' = n + 1, for the n with t <= n + 1
                its_ = [it for it in TE if it["n"] + 1 >= t]; Ak = kn_answers(its_, lambda n_: n_ + 1, skip=(t,)); Nk = np.array([it["n"] for it in its_])
                s7["skip_pass"][str(t)] = {str(n): float((Ak == np.array([it["t"] for it in its_]))[Nk == n].mean()) for n in sorted(set(Nk.tolist()))}
            ll = []                                                         # note 177-4: the whole log.jsonl history (survives --resume), not the in-memory list
            for l_ in open(os.path.join(a.out, "log.jsonl")):
                r_ = json.loads(l_)
                if r_.get("loss") is not None and "step" in r_:
                    ll.append(r_["loss"])
            tl = ll[-max(2, len(ll) // 10):]; h_ = len(tl) // 2
            s7["train_loss_tail"] = {"first_half": float(np.mean(tl[:h_])) if h_ else None, "second_half": float(np.mean(tl[h_:])) if tl else None, "n_logged": len(tl)}
            res["s177"] = s7; json.dump(kcount, open(os.path.join(a.out, "kmatch_counts.json"), "w", newline="\n"), indent=1)
        if a.path_indep and a.arm in ("inject", "readslots"):                              # §182 s182.path_indep: K' = 16 from M_0 = 0 vs from another item's 8-pass memory
            pool = [it for it in TE if 3 <= it["n"] <= 8]; its_ = [pool[i] for i in np.random.default_rng(18201).permutation(len(pool))[:500]]
            der = np.roll(np.arange(len(its_)), 1); S8 = inject_states(its_, 8)[der]; A0, A1, F0, F1 = [], [], [], []   # a fixed derangement (no fixed point)
            with torch.no_grad():
                for i in range(0, len(its_), a.eval_bs):
                    ch = its_[i:i + a.eval_bs]; x, msk = m.think_inputs(ch, dev)
                    for S0, Ao, Fo in ((None, A0, F0), (S8[i:i + a.eval_bs], A1, F1)):
                        with ac():
                            Sz = m.mem.zero_state(len(ch), dev); S = Sz if S0 is None else torch.tensor(S0, device=dev, dtype=Sz.dtype)
                            for _ in range(16):
                                S = m.write(S, x, msk)
                            lg = m.dec_logits(S, ch, dev)
                        Ao.append(lg[:, NUM_IDS].argmax(-1).cpu().numpy()); Fo.append(S[:, m.mem.h_add:m.mem.h_add + m.mem.h_del].float().flatten(1).cpu())
            A0, A1 = np.concatenate(A0), np.concatenate(A1); F0, F1 = torch.cat(F0), torch.cat(F1); tt_ = np.array([it["t"] for it in its_])
            res["s182"] = {"path_indep": {"answer_agree": float((A0 == A1).mean()), "delta_cos_final": float(Fn.cosine_similarity(F0, F1, dim=1).mean()),
                                          "n_items": len(its_), "acc_from_zero": float((A0 == tt_).mean()), "acc_from_donor": float((A1 == tt_).mean()), "kprime": 16,
                                          "donor_passes": 8, "items": "test n 3..8, rng 18201 permutation[:500]", "derangement": "np.roll(sample order, 1)",
                                          "delta_cos_def": "mean over items of cos of the final delta-head states S[:, h_add:h_add + h_del]"}, "aux_hold": bool(a.aux_hold), "k_window": a.k_window}
        if a.add_norm and m is not None:                                    # §185 fields
            gh_ = np.array(gn_hist) if gn_hist else np.array([np.nan]); gb = {}
            for st_, v_ in gadd_hist:
                gb.setdefault(str((st_ - 1) // 1000 * 1000 + 1000), []).append(v_)
            rn = {}; its_ = [it for it in TE if 3 <= it["n"] <= 8][:256]; x_, mk_ = m.think_inputs(its_, dev)
            with torch.no_grad(), ac():
                S_ = m.mem.zero_state(len(its_), dev); m.mem.norms = []
                for t_ in range(1, 17):
                    S_ = m.write(S_, x_, mk_); rn[str(t_)] = float(m.mem.norms[-1][1].median()) if m.mem.norms else None
                m.mem.norms = None
            res["s185"] = {"add_norm": a.add_norm, "clip_rate": float((gh_ > 1.0).mean()), "grad_norm_preclip": {"median": float(np.median(gh_)), "p90": float(np.percentile(gh_, 90))},
                           "grad_add": {k_: {"median": float(np.median(v_)), "p99": float(np.percentile(v_, 99))} for k_, v_ in sorted(gb.items(), key=lambda kv: int(kv[0]))},
                           "den_min_first500": ({"min": min(v_ for _, v_ in zmin_hist), "by_100": {str(b_): min(v_ for s_, v_ in zmin_hist if (s_ - 1) // 100 == b_ // 100 - 1)
                                                for b_ in range(100, 501, 100) if any((s_ - 1) // 100 == b_ // 100 - 1 for s_, _ in zmin_hist)}, "n_steps": len(zmin_hist)}
                                                if zmin_hist else None),
                           "read_norm_by_pass": rn, "read_norm_def": "median ||g_add * additive read|| at each think pass's last token (mem.norms), 256 test items n 3..8",
                           "grad_add_def": "per step the norm of the additive heads' q / k / v rows of qkv.weight.grad (+ the rms gain), median / p99 per 1k steps"}
        if a.aux_reweight:                                                  # §184 fields
            gh_ = np.array(gn_hist) if gn_hist else np.array([np.nan])
            res["s184"] = {"aux_reweight": True, "weights": list(AUX_W), "clip_rate": float((gh_ > 1.0).mean()), "grad_norm_preclip": {"median": float(np.median(gh_)),
                           "p90": float(np.percentile(gh_, 90)), "n_steps": int(len(gn_hist))}, "def": "clip_grad_norm_(..., 1.0)'s pre-clip total norm per training step; clip fires when > 1.0"}
        if a.aux_step and K:                                                # §175 (the aux is dropped at test; every §170 field comes from the main decoder)
            res["s175"] = s175_fields()
    res["eval_sec"] = round(time.time() - t1); json.dump(res, open(os.path.join(a.out, "eval.json"), "w", newline="\n"), indent=1)
    for ck_ in ("ckpt_last.pt", "ckpt_prev.pt"):
        if os.path.exists(os.path.join(a.out, ck_)):
            os.remove(os.path.join(a.out, ck_))
    print("EVAL", json.dumps({"acc_by_n": res["acc_by_n"]}), flush=True); print("DONE", a.out, flush=True)


def serial_items(items, rng):
    """§170 SERIAL: recipients whose root has a bare-number operand a and whose innermost handle h (the first CoT reduction) is not the root; donor = h's
    operands changed (v -> v' != v) and a -> a' != a; hybrid = the recipient with h -> v' (a kept). Kept: hybrid != recipient and != donor answers."""
    rec, don, hyb = [], [], []
    for it in items:
        root = it["root"]
        if root.op is None:
            continue
        side = "l" if root.l.op is None else ("r" if root.r.op is None else None)
        path = _leftmost_ready(root)
        if side is None or path is None or len(path) == 0:
            continue
        got = None
        for _ in range(10):                                                 # a new value / operand can divide by 0 somewhere above: redraw
            d = _copy(root); hn = d
            for p_ in path:
                hn = getattr(hn, p_)
            v = apply(hn.op, hn.l.v, hn.r.v); v2 = int(rng.choice([x for x in range(P) if x != v])); prs = PAIRS[(hn.op, v2)]; a_, b_ = prs[int(rng.integers(0, len(prs)))]
            hb = _copy(root); hh = hb
            for p_ in path:
                hh = getattr(hh, p_)
            hh.l.v, hh.r.v = a_, b_; hn.l.v, hn.r.v = a_, b_; bare = getattr(d, side); bare.v = int(rng.choice([x for x in range(P) if x != bare.v]))
            try:
                got = (value(hb), value(d)); break
            except KeyError:
                continue
        if got is None:
            continue
        hyb_v, don_v = got
        if hyb_v != value(root) and hyb_v != don_v:
            rec.append(it); don.append({"syms": render(d), "t": don_v, "root": d, "n": it["n"]}); hyb.append(hyb_v)
    return rec, don, hyb


if __name__ == "__main__":
    main()
